<!DOCTYPE html>
<html lang="fr-FR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11"> 
	<meta name='robots' content='noindex, follow' />
	<style>img:is([sizes="auto" i], [sizes^="auto," i]) { contain-intrinsic-size: 3000px 1500px }</style>
		<!-- Pixel Cat Facebook Pixel Code -->
	<script>
	!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
	n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
	n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
	t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
	document,'script','https://connect.facebook.net/en_US/fbevents.js' );
	fbq( 'init', '2939292989714585' );	</script>
	<!-- DO NOT MODIFY -->
	<!-- End Facebook Pixel Code -->
	
	<!-- This site is optimized with the Yoast SEO Premium plugin v26.2 (Yoast SEO v26.5) - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Page non trouvée - Cash Flow Positif</title>
	<meta property="og:locale" content="fr_FR" />
	<meta property="og:title" content="Page non trouvée - Cash Flow Positif" />
	<meta property="og:site_name" content="Cash Flow Positif" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://cashflowpositif.com/#website","url":"https://cashflowpositif.com/","name":"Cash Flow Positif","description":"L&#039;immobilier locatif rentable","publisher":{"@id":"https://cashflowpositif.com/#organization"},"potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://cashflowpositif.com/?s={search_term_string}"},"query-input":{"@type":"PropertyValueSpecification","valueRequired":true,"valueName":"search_term_string"}}],"inLanguage":"fr-FR"},{"@type":"Organization","@id":"https://cashflowpositif.com/#organization","name":"Cash Flow Positif","url":"https://cashflowpositif.com/","logo":{"@type":"ImageObject","inLanguage":"fr-FR","@id":"https://cashflowpositif.com/#/schema/logo/image/","url":"https://cashflowpositif.com/wp-content/uploads/2024/06/cropped-Trouvez-un-investissement-immobilier-rentable-en-temps-de-crise-13.png","contentUrl":"https://cashflowpositif.com/wp-content/uploads/2024/06/cropped-Trouvez-un-investissement-immobilier-rentable-en-temps-de-crise-13.png","width":1080,"height":360,"caption":"Cash Flow Positif"},"image":{"@id":"https://cashflowpositif.com/#/schema/logo/image/"}}]}</script>
	<!-- / Yoast SEO Premium plugin. -->


<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="Cash Flow Positif &raquo; Flux" href="https://cashflowpositif.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Cash Flow Positif &raquo; Flux des commentaires" href="https://cashflowpositif.com/comments/feed/" />
<script>
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/16.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/16.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/cashflowpositif.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.8.3"}};
/*! This file is auto-generated */
!function(s,n){var o,i,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),a=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===a[t]})}function u(e,t){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);for(var n=e.getImageData(16,16,1,1),a=0;a<n.data.length;a++)if(0!==n.data[a])return!1;return!0}function f(e,t,n,a){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\udde8\ud83c\uddf6","\ud83c\udde8\u200b\ud83c\uddf6")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!a(e,"\ud83e\udedf")}return!1}function g(e,t,n,a){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):s.createElement("canvas"),o=r.getContext("2d",{willReadFrequently:!0}),i=(o.textBaseline="top",o.font="600 32px Arial",{});return e.forEach(function(e){i[e]=t(o,e,n,a)}),i}function t(e){var t=s.createElement("script");t.src=e,t.defer=!0,s.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",i=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){s.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+g.toString()+"("+[JSON.stringify(i),f.toString(),p.toString(),u.toString()].join(",")+"));",a=new Blob([e],{type:"text/javascript"}),r=new Worker(URL.createObjectURL(a),{name:"wpTestEmojiSupports"});return void(r.onmessage=function(e){c(n=e.data),r.terminate(),t(n)})}catch(e){}c(n=g(i,f,p,u))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
</script>
<link rel='stylesheet' id='astra-theme-css-css' href='https://cashflowpositif.com/wp-content/themes/astra/assets/css/minified/main.min.css?ver=4.11.16' media='all' />
<style id='astra-theme-css-inline-css'>
:root{--ast-post-nav-space:0;--ast-container-default-xlg-padding:6.67em;--ast-container-default-lg-padding:5.67em;--ast-container-default-slg-padding:4.34em;--ast-container-default-md-padding:3.34em;--ast-container-default-sm-padding:6.67em;--ast-container-default-xs-padding:2.4em;--ast-container-default-xxs-padding:1.4em;--ast-code-block-background:#EEEEEE;--ast-comment-inputs-background:#FAFAFA;--ast-normal-container-width:1398px;--ast-narrow-container-width:750px;--ast-blog-title-font-weight:normal;--ast-blog-meta-weight:inherit;--ast-global-color-primary:var(--ast-global-color-5);--ast-global-color-secondary:var(--ast-global-color-4);--ast-global-color-alternate-background:var(--ast-global-color-7);--ast-global-color-subtle-background:var(--ast-global-color-6);--ast-bg-style-guide:#F8FAFC;--ast-shadow-style-guide:0px 0px 4px 0 #00000057;--ast-global-dark-bg-style:#fff;--ast-global-dark-lfs:#fbfbfb;--ast-widget-bg-color:#fafafa;--ast-wc-container-head-bg-color:#fbfbfb;--ast-title-layout-bg:#eeeeee;--ast-search-border-color:#e7e7e7;--ast-lifter-hover-bg:#e6e6e6;--ast-gallery-block-color:#000;--srfm-color-input-label:var(--ast-global-color-2);}html{font-size:93.75%;}a,.page-title{color:var(--ast-global-color-8);}a:hover,a:focus{color:var(--ast-global-color-1);}body,button,input,select,textarea,.ast-button,.ast-custom-button{font-family:'Open Sans',sans-serif;font-weight:400;font-size:15px;font-size:1rem;line-height:var(--ast-body-line-height,1.65em);}blockquote{color:var(--ast-global-color-3);}h1,h2,h3,h4,h5,h6,.entry-content :where(h1,h2,h3,h4,h5,h6),.site-title,.site-title a{font-family:'Montserrat',sans-serif;font-weight:700;}.site-title{font-size:35px;font-size:2.3333333333333rem;display:none;}header .custom-logo-link img{max-width:158px;width:158px;}.astra-logo-svg{width:158px;}.site-header .site-description{font-size:15px;font-size:1rem;display:none;}.entry-title{font-size:25px;font-size:1.6666666666667rem;}.ast-blog-single-element.ast-taxonomy-container a{font-size:11px;font-size:0.73333333333333rem;}.ast-blog-meta-container{font-size:15px;font-size:1rem;}.archive .ast-article-post .ast-article-inner,.blog .ast-article-post .ast-article-inner,.archive .ast-article-post .ast-article-inner:hover,.blog .ast-article-post .ast-article-inner:hover{overflow:hidden;}h1,.entry-content :where(h1){font-size:90px;font-size:6rem;font-weight:700;font-family:'Montserrat',sans-serif;line-height:1.4em;text-transform:uppercase;}h2,.entry-content :where(h2){font-size:40px;font-size:2.6666666666667rem;font-weight:700;font-family:'Montserrat',sans-serif;line-height:1.3em;}h3,.entry-content :where(h3){font-size:24px;font-size:1.6rem;font-weight:700;font-family:'Montserrat',sans-serif;line-height:1.3em;}h4,.entry-content :where(h4){font-size:24px;font-size:1.6rem;line-height:1.2em;font-weight:700;font-family:'Montserrat',sans-serif;}h5,.entry-content :where(h5){font-size:20px;font-size:1.3333333333333rem;line-height:1.2em;font-weight:700;font-family:'Montserrat',sans-serif;}h6,.entry-content :where(h6){font-size:16px;font-size:1.0666666666667rem;line-height:1.25em;font-weight:700;font-family:'Montserrat',sans-serif;}::selection{background-color:#0085ff;color:#ffffff;}body,h1,h2,h3,h4,h5,h6,.entry-title a,.entry-content :where(h1,h2,h3,h4,h5,h6){color:var(--ast-global-color-3);}.tagcloud a:hover,.tagcloud a:focus,.tagcloud a.current-item{color:#ffffff;border-color:var(--ast-global-color-8);background-color:var(--ast-global-color-8);}input:focus,input[type="text"]:focus,input[type="email"]:focus,input[type="url"]:focus,input[type="password"]:focus,input[type="reset"]:focus,input[type="search"]:focus,textarea:focus{border-color:var(--ast-global-color-8);}input[type="radio"]:checked,input[type=reset],input[type="checkbox"]:checked,input[type="checkbox"]:hover:checked,input[type="checkbox"]:focus:checked,input[type=range]::-webkit-slider-thumb{border-color:var(--ast-global-color-8);background-color:var(--ast-global-color-8);box-shadow:none;}.site-footer a:hover + .post-count,.site-footer a:focus + .post-count{background:var(--ast-global-color-8);border-color:var(--ast-global-color-8);}.single .nav-links .nav-previous,.single .nav-links .nav-next{color:var(--ast-global-color-8);}.entry-meta,.entry-meta *{line-height:1.45;color:var(--ast-global-color-8);}.entry-meta a:not(.ast-button):hover,.entry-meta a:not(.ast-button):hover *,.entry-meta a:not(.ast-button):focus,.entry-meta a:not(.ast-button):focus *,.page-links > .page-link,.page-links .page-link:hover,.post-navigation a:hover{color:var(--ast-global-color-1);}#cat option,.secondary .calendar_wrap thead a,.secondary .calendar_wrap thead a:visited{color:var(--ast-global-color-8);}.secondary .calendar_wrap #today,.ast-progress-val span{background:var(--ast-global-color-8);}.secondary a:hover + .post-count,.secondary a:focus + .post-count{background:var(--ast-global-color-8);border-color:var(--ast-global-color-8);}.calendar_wrap #today > a{color:#ffffff;}.page-links .page-link,.single .post-navigation a{color:var(--ast-global-color-8);}.ast-search-menu-icon .search-form button.search-submit{padding:0 4px;}.ast-search-menu-icon form.search-form{padding-right:0;}.ast-search-menu-icon.slide-search input.search-field{width:0;}.ast-header-search .ast-search-menu-icon.ast-dropdown-active .search-form,.ast-header-search .ast-search-menu-icon.ast-dropdown-active .search-field:focus{transition:all 0.2s;}.search-form input.search-field:focus{outline:none;}.ast-archive-title{color:#1c1c1c;}.wp-block-latest-posts > li > a{color:#1c1c1c;}.widget-title,.widget .wp-block-heading{font-size:21px;font-size:1.4rem;color:#1c1c1c;}.ast-search-menu-icon.slide-search a:focus-visible:focus-visible,.astra-search-icon:focus-visible,#close:focus-visible,a:focus-visible,.ast-menu-toggle:focus-visible,.site .skip-link:focus-visible,.wp-block-loginout input:focus-visible,.wp-block-search.wp-block-search__button-inside .wp-block-search__inside-wrapper,.ast-header-navigation-arrow:focus-visible,.ast-orders-table__row .ast-orders-table__cell:focus-visible,a#ast-apply-coupon:focus-visible,#ast-apply-coupon:focus-visible,#close:focus-visible,.button.search-submit:focus-visible,#search_submit:focus,.normal-search:focus-visible,.ast-header-account-wrap:focus-visible,.astra-cart-drawer-close:focus,.ast-single-variation:focus,.ast-button:focus{outline-style:dotted;outline-color:inherit;outline-width:thin;}input:focus,input[type="text"]:focus,input[type="email"]:focus,input[type="url"]:focus,input[type="password"]:focus,input[type="reset"]:focus,input[type="search"]:focus,input[type="number"]:focus,textarea:focus,.wp-block-search__input:focus,[data-section="section-header-mobile-trigger"] .ast-button-wrap .ast-mobile-menu-trigger-minimal:focus,.ast-mobile-popup-drawer.active .menu-toggle-close:focus,#ast-scroll-top:focus,#coupon_code:focus,#ast-coupon-code:focus{border-style:dotted;border-color:inherit;border-width:thin;}input{outline:none;}.ast-logo-title-inline .site-logo-img{padding-right:1em;}.site-logo-img img{ transition:all 0.2s linear;}body .ast-oembed-container *{position:absolute;top:0;width:100%;height:100%;left:0;}body .wp-block-embed-pocket-casts .ast-oembed-container *{position:unset;}.ast-single-post-featured-section + article {margin-top: 2em;}.site-content .ast-single-post-featured-section img {width: 100%;overflow: hidden;object-fit: cover;}.ast-separate-container .site-content .ast-single-post-featured-section + article {margin-top: -80px;z-index: 9;position: relative;border-radius: 4px;}@media (min-width: 922px) {.ast-no-sidebar .site-content .ast-article-image-container--wide {margin-left: -120px;margin-right: -120px;max-width: unset;width: unset;}.ast-left-sidebar .site-content .ast-article-image-container--wide,.ast-right-sidebar .site-content .ast-article-image-container--wide {margin-left: -10px;margin-right: -10px;}.site-content .ast-article-image-container--full {margin-left: calc( -50vw + 50%);margin-right: calc( -50vw + 50%);max-width: 100vw;width: 100vw;}.ast-left-sidebar .site-content .ast-article-image-container--full,.ast-right-sidebar .site-content .ast-article-image-container--full {margin-left: -10px;margin-right: -10px;max-width: inherit;width: auto;}}.site > .ast-single-related-posts-container {margin-top: 0;}@media (min-width: 922px) {.ast-desktop .ast-container--narrow {max-width: var(--ast-narrow-container-width);margin: 0 auto;}}@media (max-width:921.9px){#ast-desktop-header{display:none;}}@media (min-width:922px){#ast-mobile-header{display:none;}}.wp-block-buttons.aligncenter{justify-content:center;}.wp-block-button.is-style-outline .wp-block-button__link{border-color:var(--ast-global-color-0);border-top-width:0px;border-right-width:0px;border-bottom-width:0px;border-left-width:0px;}div.wp-block-button.is-style-outline > .wp-block-button__link:not(.has-text-color),div.wp-block-button.wp-block-button__link.is-style-outline:not(.has-text-color){color:var(--ast-global-color-0);}.wp-block-button.is-style-outline .wp-block-button__link:hover,.wp-block-buttons .wp-block-button.is-style-outline .wp-block-button__link:focus,.wp-block-buttons .wp-block-button.is-style-outline > .wp-block-button__link:not(.has-text-color):hover,.wp-block-buttons .wp-block-button.wp-block-button__link.is-style-outline:not(.has-text-color):hover{color:var(--ast-global-color-2);background-color:var(--ast-global-color-1);border-color:var(--ast-global-color-1);}.post-page-numbers.current .page-link,.ast-pagination .page-numbers.current{color:#ffffff;border-color:#0085ff;background-color:#0085ff;}.wp-block-button.is-style-outline .wp-block-button__link{border-top-width:0px;border-right-width:0px;border-bottom-width:0px;border-left-width:0px;}.wp-block-button.is-style-outline .wp-block-button__link.wp-element-button,.ast-outline-button{border-color:var(--ast-global-color-0);font-family:inherit;font-weight:500;line-height:1em;border-top-left-radius:0px;border-top-right-radius:0px;border-bottom-right-radius:0px;border-bottom-left-radius:0px;}.wp-block-buttons .wp-block-button.is-style-outline > .wp-block-button__link:not(.has-text-color),.wp-block-buttons .wp-block-button.wp-block-button__link.is-style-outline:not(.has-text-color),.ast-outline-button{color:var(--ast-global-color-0);}.wp-block-button.is-style-outline .wp-block-button__link:hover,.wp-block-buttons .wp-block-button.is-style-outline .wp-block-button__link:focus,.wp-block-buttons .wp-block-button.is-style-outline > .wp-block-button__link:not(.has-text-color):hover,.wp-block-buttons .wp-block-button.wp-block-button__link.is-style-outline:not(.has-text-color):hover,.ast-outline-button:hover,.ast-outline-button:focus,.wp-block-uagb-buttons-child .uagb-buttons-repeater.ast-outline-button:hover,.wp-block-uagb-buttons-child .uagb-buttons-repeater.ast-outline-button:focus{color:var(--ast-global-color-2);background-color:var(--ast-global-color-1);border-color:var(--ast-global-color-0);}.wp-block-button .wp-block-button__link.wp-element-button.is-style-outline:not(.has-background),.wp-block-button.is-style-outline>.wp-block-button__link.wp-element-button:not(.has-background),.ast-outline-button{background-color:var(--ast-global-color-0);}.entry-content[data-ast-blocks-layout] > figure{margin-bottom:1em;}h1.widget-title{font-weight:700;}h2.widget-title{font-weight:700;}h3.widget-title{font-weight:700;}.elementor-widget-container .elementor-loop-container .e-loop-item[data-elementor-type="loop-item"]{width:100%;}@media (max-width:921px){.ast-left-sidebar #content > .ast-container{display:flex;flex-direction:column-reverse;width:100%;}.ast-separate-container #primary,.ast-separate-container #secondary{padding:1.5em 0;}#primary,#secondary{padding:1.5em 0;margin:0;}.ast-separate-container .ast-article-post,.ast-separate-container .ast-article-single{padding:1.5em 2.14em;}.ast-author-box img.avatar{margin:20px 0 0 0;}}@media (min-width:922px){.ast-separate-container.ast-right-sidebar #primary,.ast-separate-container.ast-left-sidebar #primary{border:0;}.search-no-results.ast-separate-container #primary{margin-bottom:4em;}}.ast-404-layout-1 .ast-404-text{font-size:200px;font-size:13.333333333333rem;}@media (min-width:922px){.error404.ast-separate-container #primary{margin-bottom:4em;}}@media (max-width:920px){.ast-404-layout-1 .ast-404-text{font-size:100px;font-size:6.6666666666667rem;}}.elementor-widget-button .elementor-button{border-style:solid;text-decoration:none;border-top-width:0px;border-right-width:0px;border-left-width:0px;border-bottom-width:0px;}body .elementor-button.elementor-size-sm,body .elementor-button.elementor-size-xs,body .elementor-button.elementor-size-md,body .elementor-button.elementor-size-lg,body .elementor-button.elementor-size-xl,body .elementor-button{border-top-left-radius:0px;border-top-right-radius:0px;border-bottom-right-radius:0px;border-bottom-left-radius:0px;padding-top:10px;padding-right:20px;padding-bottom:10px;padding-left:20px;}.elementor-widget-button .elementor-button{border-color:var(--ast-global-color-0);background-color:var(--ast-global-color-0);}.elementor-widget-button .elementor-button:hover,.elementor-widget-button .elementor-button:focus{color:var(--ast-global-color-2);background-color:var(--ast-global-color-1);border-color:var(--ast-global-color-1);}.wp-block-button .wp-block-button__link ,.elementor-widget-button .elementor-button,.elementor-widget-button .elementor-button:visited{color:var(--ast-global-color-5);}.elementor-widget-button .elementor-button{font-weight:500;line-height:1em;text-transform:uppercase;}.wp-block-button .wp-block-button__link:hover,.wp-block-button .wp-block-button__link:focus{color:var(--ast-global-color-2);background-color:var(--ast-global-color-1);border-color:var(--ast-global-color-1);}.elementor-widget-heading h1.elementor-heading-title{line-height:1.4em;}.elementor-widget-heading h2.elementor-heading-title{line-height:1.3em;}.elementor-widget-heading h3.elementor-heading-title{line-height:1.3em;}.elementor-widget-heading h4.elementor-heading-title{line-height:1.2em;}.elementor-widget-heading h5.elementor-heading-title{line-height:1.2em;}.elementor-widget-heading h6.elementor-heading-title{line-height:1.25em;}.wp-block-button .wp-block-button__link,.wp-block-search .wp-block-search__button,body .wp-block-file .wp-block-file__button{border-style:solid;border-top-width:0px;border-right-width:0px;border-left-width:0px;border-bottom-width:0px;border-color:var(--ast-global-color-0);background-color:var(--ast-global-color-0);color:var(--ast-global-color-5);font-family:inherit;font-weight:500;line-height:1em;text-transform:uppercase;border-top-left-radius:0px;border-top-right-radius:0px;border-bottom-right-radius:0px;border-bottom-left-radius:0px;padding-top:10px;padding-right:20px;padding-bottom:10px;padding-left:20px;}.menu-toggle,button,.ast-button,.ast-custom-button,.button,input#submit,input[type="button"],input[type="submit"],input[type="reset"],form[CLASS*="wp-block-search__"].wp-block-search .wp-block-search__inside-wrapper .wp-block-search__button,body .wp-block-file .wp-block-file__button{border-style:solid;border-top-width:0px;border-right-width:0px;border-left-width:0px;border-bottom-width:0px;color:var(--ast-global-color-5);border-color:var(--ast-global-color-0);background-color:var(--ast-global-color-0);padding-top:10px;padding-right:20px;padding-bottom:10px;padding-left:20px;font-family:inherit;font-weight:500;line-height:1em;text-transform:uppercase;border-top-left-radius:0px;border-top-right-radius:0px;border-bottom-right-radius:0px;border-bottom-left-radius:0px;}button:focus,.menu-toggle:hover,button:hover,.ast-button:hover,.ast-custom-button:hover .button:hover,.ast-custom-button:hover ,input[type=reset]:hover,input[type=reset]:focus,input#submit:hover,input#submit:focus,input[type="button"]:hover,input[type="button"]:focus,input[type="submit"]:hover,input[type="submit"]:focus,form[CLASS*="wp-block-search__"].wp-block-search .wp-block-search__inside-wrapper .wp-block-search__button:hover,form[CLASS*="wp-block-search__"].wp-block-search .wp-block-search__inside-wrapper .wp-block-search__button:focus,body .wp-block-file .wp-block-file__button:hover,body .wp-block-file .wp-block-file__button:focus{color:var(--ast-global-color-2);background-color:var(--ast-global-color-1);border-color:var(--ast-global-color-1);}@media (max-width:921px){.ast-mobile-header-stack .main-header-bar .ast-search-menu-icon{display:inline-block;}.ast-header-break-point.ast-header-custom-item-outside .ast-mobile-header-stack .main-header-bar .ast-search-icon{margin:0;}.ast-comment-avatar-wrap img{max-width:2.5em;}.ast-comment-meta{padding:0 1.8888em 1.3333em;}.ast-separate-container .ast-comment-list li.depth-1{padding:1.5em 2.14em;}.ast-separate-container .comment-respond{padding:2em 2.14em;}}@media (min-width:544px){.ast-container{max-width:100%;}}@media (max-width:544px){.ast-separate-container .ast-article-post,.ast-separate-container .ast-article-single,.ast-separate-container .comments-title,.ast-separate-container .ast-archive-description{padding:1.5em 1em;}.ast-separate-container #content .ast-container{padding-left:0.54em;padding-right:0.54em;}.ast-separate-container .ast-comment-list .bypostauthor{padding:.5em;}.ast-search-menu-icon.ast-dropdown-active .search-field{width:170px;}} #ast-mobile-header .ast-site-header-cart-li a{pointer-events:none;}body,.ast-separate-container{background-color:rgba(255,255,255,0.79);background-image:none;}@media (max-width:921px){.site-title{display:none;}.site-header .site-description{display:none;}h1,.entry-content :where(h1){font-size:60px;}h2,.entry-content :where(h2){font-size:35px;}h3,.entry-content :where(h3){font-size:22px;}}@media (max-width:544px){.site-title{display:none;}.site-header .site-description{display:none;}h1,.entry-content :where(h1){font-size:35px;}h2,.entry-content :where(h2){font-size:30px;}h3,.entry-content :where(h3){font-size:20px;}}@media (max-width:921px){html{font-size:85.5%;}}@media (max-width:544px){html{font-size:85.5%;}}@media (min-width:922px){.ast-container{max-width:1438px;}}@media (min-width:922px){.site-content .ast-container{display:flex;}}@media (max-width:921px){.site-content .ast-container{flex-direction:column;}}@media (min-width:922px){.main-header-menu .sub-menu .menu-item.ast-left-align-sub-menu:hover > .sub-menu,.main-header-menu .sub-menu .menu-item.ast-left-align-sub-menu.focus > .sub-menu{margin-left:-0px;}}.footer-widget-area[data-section^="section-fb-html-"] .ast-builder-html-element{text-align:center;}.wp-block-file {display: flex;align-items: center;flex-wrap: wrap;justify-content: space-between;}.wp-block-pullquote {border: none;}.wp-block-pullquote blockquote::before {content: "\201D";font-family: "Helvetica",sans-serif;display: flex;transform: rotate( 180deg );font-size: 6rem;font-style: normal;line-height: 1;font-weight: bold;align-items: center;justify-content: center;}.has-text-align-right > blockquote::before {justify-content: flex-start;}.has-text-align-left > blockquote::before {justify-content: flex-end;}figure.wp-block-pullquote.is-style-solid-color blockquote {max-width: 100%;text-align: inherit;}:root {--wp--custom--ast-default-block-top-padding: 3em;--wp--custom--ast-default-block-right-padding: 3em;--wp--custom--ast-default-block-bottom-padding: 3em;--wp--custom--ast-default-block-left-padding: 3em;--wp--custom--ast-container-width: 1398px;--wp--custom--ast-content-width-size: 1398px;--wp--custom--ast-wide-width-size: calc(1398px + var(--wp--custom--ast-default-block-left-padding) + var(--wp--custom--ast-default-block-right-padding));}.ast-narrow-container {--wp--custom--ast-content-width-size: 750px;--wp--custom--ast-wide-width-size: 750px;}@media(max-width: 921px) {:root {--wp--custom--ast-default-block-top-padding: 3em;--wp--custom--ast-default-block-right-padding: 2em;--wp--custom--ast-default-block-bottom-padding: 3em;--wp--custom--ast-default-block-left-padding: 2em;}}@media(max-width: 544px) {:root {--wp--custom--ast-default-block-top-padding: 3em;--wp--custom--ast-default-block-right-padding: 1.5em;--wp--custom--ast-default-block-bottom-padding: 3em;--wp--custom--ast-default-block-left-padding: 1.5em;}}.entry-content > .wp-block-group,.entry-content > .wp-block-cover,.entry-content > .wp-block-columns {padding-top: var(--wp--custom--ast-default-block-top-padding);padding-right: var(--wp--custom--ast-default-block-right-padding);padding-bottom: var(--wp--custom--ast-default-block-bottom-padding);padding-left: var(--wp--custom--ast-default-block-left-padding);}.ast-plain-container.ast-no-sidebar .entry-content > .alignfull,.ast-page-builder-template .ast-no-sidebar .entry-content > .alignfull {margin-left: calc( -50vw + 50%);margin-right: calc( -50vw + 50%);max-width: 100vw;width: 100vw;}.ast-plain-container.ast-no-sidebar .entry-content .alignfull .alignfull,.ast-page-builder-template.ast-no-sidebar .entry-content .alignfull .alignfull,.ast-plain-container.ast-no-sidebar .entry-content .alignfull .alignwide,.ast-page-builder-template.ast-no-sidebar .entry-content .alignfull .alignwide,.ast-plain-container.ast-no-sidebar .entry-content .alignwide .alignfull,.ast-page-builder-template.ast-no-sidebar .entry-content .alignwide .alignfull,.ast-plain-container.ast-no-sidebar .entry-content .alignwide .alignwide,.ast-page-builder-template.ast-no-sidebar .entry-content .alignwide .alignwide,.ast-plain-container.ast-no-sidebar .entry-content .wp-block-column .alignfull,.ast-page-builder-template.ast-no-sidebar .entry-content .wp-block-column .alignfull,.ast-plain-container.ast-no-sidebar .entry-content .wp-block-column .alignwide,.ast-page-builder-template.ast-no-sidebar .entry-content .wp-block-column .alignwide {margin-left: auto;margin-right: auto;width: 100%;}[data-ast-blocks-layout] .wp-block-separator:not(.is-style-dots) {height: 0;}[data-ast-blocks-layout] .wp-block-separator {margin: 20px auto;}[data-ast-blocks-layout] .wp-block-separator:not(.is-style-wide):not(.is-style-dots) {max-width: 100px;}[data-ast-blocks-layout] .wp-block-separator.has-background {padding: 0;}.entry-content[data-ast-blocks-layout] > * {max-width: var(--wp--custom--ast-content-width-size);margin-left: auto;margin-right: auto;}.entry-content[data-ast-blocks-layout] > .alignwide {max-width: var(--wp--custom--ast-wide-width-size);}.entry-content[data-ast-blocks-layout] .alignfull {max-width: none;}.entry-content .wp-block-columns {margin-bottom: 0;}blockquote {margin: 1.5em;border-color: rgba(0,0,0,0.05);}.wp-block-quote:not(.has-text-align-right):not(.has-text-align-center) {border-left: 5px solid rgba(0,0,0,0.05);}.has-text-align-right > blockquote,blockquote.has-text-align-right {border-right: 5px solid rgba(0,0,0,0.05);}.has-text-align-left > blockquote,blockquote.has-text-align-left {border-left: 5px solid rgba(0,0,0,0.05);}.wp-block-site-tagline,.wp-block-latest-posts .read-more {margin-top: 15px;}.wp-block-loginout p label {display: block;}.wp-block-loginout p:not(.login-remember):not(.login-submit) input {width: 100%;}.wp-block-loginout input:focus {border-color: transparent;}.wp-block-loginout input:focus {outline: thin dotted;}.entry-content .wp-block-media-text .wp-block-media-text__content {padding: 0 0 0 8%;}.entry-content .wp-block-media-text.has-media-on-the-right .wp-block-media-text__content {padding: 0 8% 0 0;}.entry-content .wp-block-media-text.has-background .wp-block-media-text__content {padding: 8%;}.entry-content .wp-block-cover:not([class*="background-color"]):not(.has-text-color.has-link-color) .wp-block-cover__inner-container,.entry-content .wp-block-cover:not([class*="background-color"]) .wp-block-cover-image-text,.entry-content .wp-block-cover:not([class*="background-color"]) .wp-block-cover-text,.entry-content .wp-block-cover-image:not([class*="background-color"]) .wp-block-cover__inner-container,.entry-content .wp-block-cover-image:not([class*="background-color"]) .wp-block-cover-image-text,.entry-content .wp-block-cover-image:not([class*="background-color"]) .wp-block-cover-text {color: var(--ast-global-color-primary,var(--ast-global-color-5));}.wp-block-loginout .login-remember input {width: 1.1rem;height: 1.1rem;margin: 0 5px 4px 0;vertical-align: middle;}.wp-block-latest-posts > li > *:first-child,.wp-block-latest-posts:not(.is-grid) > li:first-child {margin-top: 0;}.entry-content > .wp-block-buttons,.entry-content > .wp-block-uagb-buttons {margin-bottom: 1.5em;}.wp-block-search__inside-wrapper .wp-block-search__input {padding: 0 10px;color: var(--ast-global-color-3);background: var(--ast-global-color-primary,var(--ast-global-color-5));border-color: var(--ast-border-color);}.wp-block-latest-posts .read-more {margin-bottom: 1.5em;}.wp-block-search__no-button .wp-block-search__inside-wrapper .wp-block-search__input {padding-top: 5px;padding-bottom: 5px;}.wp-block-latest-posts .wp-block-latest-posts__post-date,.wp-block-latest-posts .wp-block-latest-posts__post-author {font-size: 1rem;}.wp-block-latest-posts > li > *,.wp-block-latest-posts:not(.is-grid) > li {margin-top: 12px;margin-bottom: 12px;}.ast-page-builder-template .entry-content[data-ast-blocks-layout] > .alignwide:where(:not(.uagb-is-root-container):not(.spectra-is-root-container)) > * {max-width: var(--wp--custom--ast-wide-width-size);}.ast-page-builder-template .entry-content[data-ast-blocks-layout] > .inherit-container-width > *,.ast-page-builder-template .entry-content[data-ast-blocks-layout] > *:not(.wp-block-group):where(:not(.uagb-is-root-container):not(.spectra-is-root-container)) > *,.entry-content[data-ast-blocks-layout] > .wp-block-cover .wp-block-cover__inner-container {max-width: none ;margin-left: auto;margin-right: auto;}.ast-page-builder-template .entry-content[data-ast-blocks-layout] > *,.ast-page-builder-template .entry-content[data-ast-blocks-layout] > .alignfull:where(:not(.wp-block-group):not(.uagb-is-root-container):not(.spectra-is-root-container)) > * {max-width: none;}.entry-content[data-ast-blocks-layout] .wp-block-cover:not(.alignleft):not(.alignright) {width: auto;}@media(max-width: 1200px) {.ast-separate-container .entry-content > .alignfull,.ast-separate-container .entry-content[data-ast-blocks-layout] > .alignwide,.ast-plain-container .entry-content[data-ast-blocks-layout] > .alignwide,.ast-plain-container .entry-content .alignfull {margin-left: calc(-1 * min(var(--ast-container-default-xlg-padding),20px)) ;margin-right: calc(-1 * min(var(--ast-container-default-xlg-padding),20px));}}@media(min-width: 1201px) {.ast-separate-container .entry-content > .alignfull {margin-left: calc(-1 * var(--ast-container-default-xlg-padding) );margin-right: calc(-1 * var(--ast-container-default-xlg-padding) );}.ast-separate-container .entry-content[data-ast-blocks-layout] > .alignwide,.ast-plain-container .entry-content[data-ast-blocks-layout] > .alignwide {margin-left: calc(-1 * var(--wp--custom--ast-default-block-left-padding) );margin-right: calc(-1 * var(--wp--custom--ast-default-block-right-padding) );}}@media(min-width: 921px) {.ast-separate-container .entry-content .wp-block-group.alignwide:not(.inherit-container-width) > :where(:not(.alignleft):not(.alignright)),.ast-plain-container .entry-content .wp-block-group.alignwide:not(.inherit-container-width) > :where(:not(.alignleft):not(.alignright)) {max-width: calc( var(--wp--custom--ast-content-width-size) + 80px );}.ast-plain-container.ast-right-sidebar .entry-content[data-ast-blocks-layout] .alignfull,.ast-plain-container.ast-left-sidebar .entry-content[data-ast-blocks-layout] .alignfull {margin-left: -60px;margin-right: -60px;}}@media(min-width: 544px) {.entry-content > .alignleft {margin-right: 20px;}.entry-content > .alignright {margin-left: 20px;}}@media (max-width:544px){.wp-block-columns .wp-block-column:not(:last-child){margin-bottom:20px;}.wp-block-latest-posts{margin:0;}}@media( max-width: 600px ) {.entry-content .wp-block-media-text .wp-block-media-text__content,.entry-content .wp-block-media-text.has-media-on-the-right .wp-block-media-text__content {padding: 8% 0 0;}.entry-content .wp-block-media-text.has-background .wp-block-media-text__content {padding: 8%;}}.ast-page-builder-template .entry-header {padding-left: 0;}.ast-narrow-container .site-content .wp-block-uagb-image--align-full .wp-block-uagb-image__figure {max-width: 100%;margin-left: auto;margin-right: auto;}:root .has-ast-global-color-0-color{color:var(--ast-global-color-0);}:root .has-ast-global-color-0-background-color{background-color:var(--ast-global-color-0);}:root .wp-block-button .has-ast-global-color-0-color{color:var(--ast-global-color-0);}:root .wp-block-button .has-ast-global-color-0-background-color{background-color:var(--ast-global-color-0);}:root .has-ast-global-color-1-color{color:var(--ast-global-color-1);}:root .has-ast-global-color-1-background-color{background-color:var(--ast-global-color-1);}:root .wp-block-button .has-ast-global-color-1-color{color:var(--ast-global-color-1);}:root .wp-block-button .has-ast-global-color-1-background-color{background-color:var(--ast-global-color-1);}:root .has-ast-global-color-2-color{color:var(--ast-global-color-2);}:root .has-ast-global-color-2-background-color{background-color:var(--ast-global-color-2);}:root .wp-block-button .has-ast-global-color-2-color{color:var(--ast-global-color-2);}:root .wp-block-button .has-ast-global-color-2-background-color{background-color:var(--ast-global-color-2);}:root .has-ast-global-color-3-color{color:var(--ast-global-color-3);}:root .has-ast-global-color-3-background-color{background-color:var(--ast-global-color-3);}:root .wp-block-button .has-ast-global-color-3-color{color:var(--ast-global-color-3);}:root .wp-block-button .has-ast-global-color-3-background-color{background-color:var(--ast-global-color-3);}:root .has-ast-global-color-4-color{color:var(--ast-global-color-4);}:root .has-ast-global-color-4-background-color{background-color:var(--ast-global-color-4);}:root .wp-block-button .has-ast-global-color-4-color{color:var(--ast-global-color-4);}:root .wp-block-button .has-ast-global-color-4-background-color{background-color:var(--ast-global-color-4);}:root .has-ast-global-color-5-color{color:var(--ast-global-color-5);}:root .has-ast-global-color-5-background-color{background-color:var(--ast-global-color-5);}:root .wp-block-button .has-ast-global-color-5-color{color:var(--ast-global-color-5);}:root .wp-block-button .has-ast-global-color-5-background-color{background-color:var(--ast-global-color-5);}:root .has-ast-global-color-6-color{color:var(--ast-global-color-6);}:root .has-ast-global-color-6-background-color{background-color:var(--ast-global-color-6);}:root .wp-block-button .has-ast-global-color-6-color{color:var(--ast-global-color-6);}:root .wp-block-button .has-ast-global-color-6-background-color{background-color:var(--ast-global-color-6);}:root .has-ast-global-color-7-color{color:var(--ast-global-color-7);}:root .has-ast-global-color-7-background-color{background-color:var(--ast-global-color-7);}:root .wp-block-button .has-ast-global-color-7-color{color:var(--ast-global-color-7);}:root .wp-block-button .has-ast-global-color-7-background-color{background-color:var(--ast-global-color-7);}:root .has-ast-global-color-8-color{color:var(--ast-global-color-8);}:root .has-ast-global-color-8-background-color{background-color:var(--ast-global-color-8);}:root .wp-block-button .has-ast-global-color-8-color{color:var(--ast-global-color-8);}:root .wp-block-button .has-ast-global-color-8-background-color{background-color:var(--ast-global-color-8);}:root{--ast-global-color-0:#3ea2ff;--ast-global-color-1:#0085ff;--ast-global-color-2:#0F172A;--ast-global-color-3:#364151;--ast-global-color-4:#E7F6FF;--ast-global-color-5:#FFFFFF;--ast-global-color-6:#D1DAE5;--ast-global-color-7:#070614;--ast-global-color-8:#222222;}:root {--ast-border-color : #dddddd;}.ast-breadcrumbs .trail-browse,.ast-breadcrumbs .trail-items,.ast-breadcrumbs .trail-items li{display:inline-block;margin:0;padding:0;border:none;background:inherit;text-indent:0;text-decoration:none;}.ast-breadcrumbs .trail-browse{font-size:inherit;font-style:inherit;font-weight:inherit;color:inherit;}.ast-breadcrumbs .trail-items{list-style:none;}.trail-items li::after{padding:0 0.3em;content:"\00bb";}.trail-items li:last-of-type::after{display:none;}.trail-items li::after{content:"\003E";}.ast-breadcrumbs-wrapper{text-align:left;}.ast-default-menu-enable.ast-main-header-nav-open.ast-header-break-point .main-header-bar.ast-header-breadcrumb,.ast-main-header-nav-open .main-header-bar.ast-header-breadcrumb{padding-top:1em;padding-bottom:1em;}.ast-header-break-point .main-header-bar.ast-header-breadcrumb{border-bottom-width:1px;border-bottom-color:#eaeaea;border-bottom-style:solid;}.ast-breadcrumbs-wrapper{line-height:1.4;}.ast-breadcrumbs-wrapper .rank-math-breadcrumb p{margin-bottom:0px;}.ast-breadcrumbs-wrapper{display:block;width:100%;}h1,h2,h3,h4,h5,h6,.entry-content :where(h1,h2,h3,h4,h5,h6){color:#1c1c1c;}.entry-title a{color:#1c1c1c;}@media (max-width:921px){.ast-builder-grid-row-container.ast-builder-grid-row-tablet-3-firstrow .ast-builder-grid-row > *:first-child,.ast-builder-grid-row-container.ast-builder-grid-row-tablet-3-lastrow .ast-builder-grid-row > *:last-child{grid-column:1 / -1;}}@media (max-width:544px){.ast-builder-grid-row-container.ast-builder-grid-row-mobile-3-firstrow .ast-builder-grid-row > *:first-child,.ast-builder-grid-row-container.ast-builder-grid-row-mobile-3-lastrow .ast-builder-grid-row > *:last-child{grid-column:1 / -1;}}.ast-builder-layout-element[data-section="title_tagline"]{display:flex;}@media (max-width:921px){.ast-header-break-point .ast-builder-layout-element[data-section="title_tagline"]{display:flex;}}@media (max-width:544px){.ast-header-break-point .ast-builder-layout-element[data-section="title_tagline"]{display:flex;}}[data-section*="section-hb-button-"] .menu-link{display:none;}.ast-header-button-1[data-section*="section-hb-button-"] .ast-builder-button-wrap .ast-custom-button{font-family:'Poppins',sans-serif;font-weight:500;font-size:1rem;text-transform:uppercase;text-decoration:initial;}.ast-header-button-1 .ast-custom-button{color:var(--ast-global-color-5);background:var(--ast-global-color-1);border-color:var(--ast-global-color-1);border-top-width:1px;border-bottom-width:1px;border-left-width:1px;border-right-width:1px;border-top-left-radius:10px;border-top-right-radius:10px;border-bottom-right-radius:10px;border-bottom-left-radius:10px;}.ast-header-button-1 .ast-custom-button:hover{color:var(--ast-global-color-1);background:rgba(255,255,255,0);border-color:var(--ast-global-color-1);}.ast-header-button-1[data-section*="section-hb-button-"] .ast-builder-button-wrap .ast-custom-button{padding-top:16px;padding-bottom:16px;padding-left:24px;padding-right:24px;}.ast-header-button-1[data-section="section-hb-button-1"]{display:flex;}@media (max-width:921px){.ast-header-break-point .ast-header-button-1[data-section="section-hb-button-1"]{display:flex;}}@media (max-width:544px){.ast-header-break-point .ast-header-button-1[data-section="section-hb-button-1"]{display:flex;}}.ast-builder-menu-1{font-family:'Poppins',sans-serif;font-weight:500;}.ast-builder-menu-1 .menu-item > .menu-link{font-size:1rem;color:var(--ast-global-color-7);}.ast-builder-menu-1 .menu-item > .ast-menu-toggle{color:var(--ast-global-color-7);}.ast-builder-menu-1 .menu-item:hover > .menu-link,.ast-builder-menu-1 .inline-on-mobile .menu-item:hover > .ast-menu-toggle{color:var(--ast-global-color-0);}.ast-builder-menu-1 .menu-item:hover > .ast-menu-toggle{color:var(--ast-global-color-0);}.ast-builder-menu-1 .menu-item.current-menu-item > .menu-link,.ast-builder-menu-1 .inline-on-mobile .menu-item.current-menu-item > .ast-menu-toggle,.ast-builder-menu-1 .current-menu-ancestor > .menu-link{color:var(--ast-global-color-0);}.ast-builder-menu-1 .menu-item.current-menu-item > .ast-menu-toggle{color:var(--ast-global-color-0);}.ast-builder-menu-1 .sub-menu,.ast-builder-menu-1 .inline-on-mobile .sub-menu{border-top-width:0px;border-bottom-width:0px;border-right-width:0px;border-left-width:0px;border-color:#0085ff;border-style:solid;}.ast-builder-menu-1 .sub-menu .sub-menu{top:0px;}.ast-builder-menu-1 .main-header-menu > .menu-item > .sub-menu,.ast-builder-menu-1 .main-header-menu > .menu-item > .astra-full-megamenu-wrapper{margin-top:0px;}.ast-desktop .ast-builder-menu-1 .main-header-menu > .menu-item > .sub-menu:before,.ast-desktop .ast-builder-menu-1 .main-header-menu > .menu-item > .astra-full-megamenu-wrapper:before{height:calc( 0px + 0px + 5px );}.ast-desktop .ast-builder-menu-1 .menu-item .sub-menu .menu-link{border-style:none;}@media (max-width:921px){.ast-header-break-point .ast-builder-menu-1 .menu-item.menu-item-has-children > .ast-menu-toggle{top:0;}.ast-builder-menu-1 .inline-on-mobile .menu-item.menu-item-has-children > .ast-menu-toggle{right:-15px;}.ast-builder-menu-1 .menu-item-has-children > .menu-link:after{content:unset;}.ast-builder-menu-1 .main-header-menu > .menu-item > .sub-menu,.ast-builder-menu-1 .main-header-menu > .menu-item > .astra-full-megamenu-wrapper{margin-top:0;}}@media (max-width:544px){.ast-header-break-point .ast-builder-menu-1 .menu-item.menu-item-has-children > .ast-menu-toggle{top:0;}.ast-builder-menu-1 .main-header-menu > .menu-item > .sub-menu,.ast-builder-menu-1 .main-header-menu > .menu-item > .astra-full-megamenu-wrapper{margin-top:0;}}.ast-builder-menu-1{display:flex;}@media (max-width:921px){.ast-header-break-point .ast-builder-menu-1{display:flex;}}@media (max-width:544px){.ast-header-break-point .ast-builder-menu-1{display:flex;}}.site-below-footer-wrap{padding-top:20px;padding-bottom:20px;}.site-below-footer-wrap[data-section="section-below-footer-builder"]{background-image:none;min-height:96px;border-style:solid;border-width:0px;border-top-width:1px;border-top-color:rgba(195,193,193,0.27);}.site-below-footer-wrap[data-section="section-below-footer-builder"] .ast-builder-grid-row{grid-column-gap:0px;max-width:1398px;min-height:96px;margin-left:auto;margin-right:auto;}.site-below-footer-wrap[data-section="section-below-footer-builder"] .ast-builder-grid-row,.site-below-footer-wrap[data-section="section-below-footer-builder"] .site-footer-section{align-items:center;}.site-below-footer-wrap[data-section="section-below-footer-builder"].ast-footer-row-inline .site-footer-section{display:flex;margin-bottom:0;}.ast-builder-grid-row-2-equal .ast-builder-grid-row{grid-template-columns:repeat( 2,1fr );}@media (max-width:921px){.site-below-footer-wrap[data-section="section-below-footer-builder"].ast-footer-row-tablet-inline .site-footer-section{display:flex;margin-bottom:0;}.site-below-footer-wrap[data-section="section-below-footer-builder"].ast-footer-row-tablet-stack .site-footer-section{display:block;margin-bottom:10px;}.ast-builder-grid-row-container.ast-builder-grid-row-tablet-2-equal .ast-builder-grid-row{grid-template-columns:repeat( 2,1fr );}}@media (max-width:544px){.site-below-footer-wrap[data-section="section-below-footer-builder"].ast-footer-row-mobile-inline .site-footer-section{display:flex;margin-bottom:0;}.site-below-footer-wrap[data-section="section-below-footer-builder"].ast-footer-row-mobile-stack .site-footer-section{display:block;margin-bottom:10px;}.ast-builder-grid-row-container.ast-builder-grid-row-mobile-full .ast-builder-grid-row{grid-template-columns:1fr;}}@media (max-width:921px){.site-below-footer-wrap[data-section="section-below-footer-builder"]{padding-left:40px;padding-right:40px;}}@media (max-width:544px){.site-below-footer-wrap[data-section="section-below-footer-builder"]{padding-top:26px;padding-bottom:26px;padding-left:26px;padding-right:26px;}}.site-below-footer-wrap[data-section="section-below-footer-builder"]{display:grid;}@media (max-width:921px){.ast-header-break-point .site-below-footer-wrap[data-section="section-below-footer-builder"]{display:grid;}}@media (max-width:544px){.ast-header-break-point .site-below-footer-wrap[data-section="section-below-footer-builder"]{display:grid;}}.ast-builder-html-element img.alignnone{display:inline-block;}.ast-builder-html-element p:first-child{margin-top:0;}.ast-builder-html-element p:last-child{margin-bottom:0;}.ast-header-break-point .main-header-bar .ast-builder-html-element{line-height:1.85714285714286;}.footer-widget-area[data-section="section-fb-html-1"]{margin-top:0px;margin-bottom:0px;margin-left:0px;margin-right:0px;}.footer-widget-area[data-section="section-fb-html-1"]{display:block;}@media (max-width:921px){.ast-header-break-point .footer-widget-area[data-section="section-fb-html-1"]{display:block;}}@media (max-width:544px){.ast-header-break-point .footer-widget-area[data-section="section-fb-html-1"]{display:block;}}.footer-widget-area[data-section="section-fb-html-1"] .ast-builder-html-element{text-align:right;}@media (max-width:921px){.footer-widget-area[data-section="section-fb-html-1"] .ast-builder-html-element{text-align:center;}}@media (max-width:544px){.footer-widget-area[data-section="section-fb-html-1"] .ast-builder-html-element{text-align:center;}}.ast-footer-copyright{text-align:left;}.ast-footer-copyright.site-footer-focus-item {color:#ffffff;}@media (max-width:921px){.ast-footer-copyright{text-align:center;}}@media (max-width:544px){.ast-footer-copyright{text-align:center;}}.ast-footer-copyright.ast-builder-layout-element{display:flex;}@media (max-width:921px){.ast-header-break-point .ast-footer-copyright.ast-builder-layout-element{display:flex;}}@media (max-width:544px){.ast-header-break-point .ast-footer-copyright.ast-builder-layout-element{display:flex;}}.ast-social-stack-desktop .ast-builder-social-element,.ast-social-stack-tablet .ast-builder-social-element,.ast-social-stack-mobile .ast-builder-social-element {margin-top: 6px;margin-bottom: 6px;}.social-show-label-true .ast-builder-social-element {width: auto;padding: 0 0.4em;}[data-section^="section-fb-social-icons-"] .footer-social-inner-wrap {text-align: center;}.ast-footer-social-wrap {width: 100%;}.ast-footer-social-wrap .ast-builder-social-element:first-child {margin-left: 0;}.ast-footer-social-wrap .ast-builder-social-element:last-child {margin-right: 0;}.ast-header-social-wrap .ast-builder-social-element:first-child {margin-left: 0;}.ast-header-social-wrap .ast-builder-social-element:last-child {margin-right: 0;}.ast-builder-social-element {line-height: 1;color: var(--ast-global-color-2);background: transparent;vertical-align: middle;transition: all 0.01s;margin-left: 6px;margin-right: 6px;justify-content: center;align-items: center;}.ast-builder-social-element .social-item-label {padding-left: 6px;}.ast-footer-social-1-wrap .ast-builder-social-element,.ast-footer-social-1-wrap .social-show-label-true .ast-builder-social-element{margin-left:6.5px;margin-right:6.5px;padding:16px;border-top-left-radius:99px;border-top-right-radius:99px;border-bottom-right-radius:99px;border-bottom-left-radius:99px;}.ast-footer-social-1-wrap .ast-builder-social-element svg{width:10px;height:10px;}.ast-footer-social-1-wrap .ast-social-icon-image-wrap{margin:16px;}.ast-footer-social-1-wrap .ast-social-color-type-custom svg{fill:var(--ast-global-color-2);}.ast-footer-social-1-wrap .ast-builder-social-element{background:var(--ast-global-color-5);}.ast-footer-social-1-wrap .ast-social-color-type-custom .ast-builder-social-element:hover{color:var(--ast-global-color-0);}.ast-footer-social-1-wrap .ast-social-color-type-custom .ast-builder-social-element:hover svg{fill:var(--ast-global-color-0);}.ast-footer-social-1-wrap .ast-social-color-type-custom .social-item-label{color:var(--ast-global-color-2);}.ast-footer-social-1-wrap .ast-builder-social-element:hover .social-item-label{color:var(--ast-global-color-0);}[data-section="section-fb-social-icons-1"] .footer-social-inner-wrap{text-align:right;}@media (max-width:921px){[data-section="section-fb-social-icons-1"] .footer-social-inner-wrap{text-align:center;}}@media (max-width:544px){.ast-footer-social-1-wrap .ast-builder-social-element svg{width:18px;height:18px;}.ast-footer-social-1-wrap .ast-builder-social-element{margin-left:6px;margin-right:6px;}.ast-footer-social-1-wrap{margin-top:4em;margin-bottom:4em;margin-left:0em;margin-right:0em;}[data-section="section-fb-social-icons-1"] .footer-social-inner-wrap{text-align:center;}}.ast-builder-layout-element[data-section="section-fb-social-icons-1"]{display:flex;}@media (max-width:921px){.ast-header-break-point .ast-builder-layout-element[data-section="section-fb-social-icons-1"]{display:flex;}}@media (max-width:544px){.ast-header-break-point .ast-builder-layout-element[data-section="section-fb-social-icons-1"]{display:flex;}}.site-footer{background-color:var(--ast-global-color-2);background-image:none;}.ast-hfb-header .site-footer{padding-top:0px;padding-bottom:0px;padding-left:0px;padding-right:0px;margin-top:0px;margin-bottom:0px;margin-left:0px;margin-right:0px;}.site-primary-footer-wrap{padding-top:45px;padding-bottom:45px;}.site-primary-footer-wrap[data-section="section-primary-footer-builder"]{background-image:none;}.site-primary-footer-wrap[data-section="section-primary-footer-builder"] .ast-builder-grid-row{max-width:100%;padding-left:35px;padding-right:35px;}.site-primary-footer-wrap[data-section="section-primary-footer-builder"] .ast-builder-grid-row,.site-primary-footer-wrap[data-section="section-primary-footer-builder"] .site-footer-section{align-items:flex-start;}.site-primary-footer-wrap[data-section="section-primary-footer-builder"].ast-footer-row-inline .site-footer-section{display:flex;margin-bottom:0;}.ast-builder-grid-row-5-equal .ast-builder-grid-row{grid-template-columns:repeat( 5,1fr );}@media (max-width:921px){.site-primary-footer-wrap[data-section="section-primary-footer-builder"].ast-footer-row-tablet-inline .site-footer-section{display:flex;margin-bottom:0;}.site-primary-footer-wrap[data-section="section-primary-footer-builder"].ast-footer-row-tablet-stack .site-footer-section{display:block;margin-bottom:10px;}.ast-builder-grid-row-container.ast-builder-grid-row-tablet-5-equal .ast-builder-grid-row{grid-template-columns:repeat( 5,1fr );}}@media (max-width:544px){.site-primary-footer-wrap[data-section="section-primary-footer-builder"].ast-footer-row-mobile-inline .site-footer-section{display:flex;margin-bottom:0;}.site-primary-footer-wrap[data-section="section-primary-footer-builder"].ast-footer-row-mobile-stack .site-footer-section{display:block;margin-bottom:10px;}.ast-builder-grid-row-container.ast-builder-grid-row-mobile-full .ast-builder-grid-row{grid-template-columns:1fr;}}.site-primary-footer-wrap[data-section="section-primary-footer-builder"]{padding-top:100px;}@media (max-width:921px){.site-primary-footer-wrap[data-section="section-primary-footer-builder"]{padding-top:80px;padding-bottom:80px;padding-left:40px;padding-right:40px;}}@media (max-width:544px){.site-primary-footer-wrap[data-section="section-primary-footer-builder"]{padding-top:026px;padding-bottom:0px;padding-left:026px;padding-right:026px;}}.site-primary-footer-wrap[data-section="section-primary-footer-builder"]{display:grid;}@media (max-width:921px){.ast-header-break-point .site-primary-footer-wrap[data-section="section-primary-footer-builder"]{display:grid;}}@media (max-width:544px){.ast-header-break-point .site-primary-footer-wrap[data-section="section-primary-footer-builder"]{display:grid;}}.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"].footer-widget-area-inner{text-align:left;}@media (max-width:921px){.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"].footer-widget-area-inner{text-align:center;}}@media (max-width:544px){.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"].footer-widget-area-inner{text-align:center;}}.footer-widget-area[data-section="sidebar-widgets-footer-widget-2"].footer-widget-area-inner{text-align:left;}@media (max-width:921px){.footer-widget-area[data-section="sidebar-widgets-footer-widget-2"].footer-widget-area-inner{text-align:center;}}@media (max-width:544px){.footer-widget-area[data-section="sidebar-widgets-footer-widget-2"].footer-widget-area-inner{text-align:center;}}.footer-widget-area[data-section="sidebar-widgets-footer-widget-3"].footer-widget-area-inner{text-align:left;}@media (max-width:921px){.footer-widget-area[data-section="sidebar-widgets-footer-widget-3"].footer-widget-area-inner{text-align:center;}}@media (max-width:544px){.footer-widget-area[data-section="sidebar-widgets-footer-widget-3"].footer-widget-area-inner{text-align:center;}}.footer-widget-area[data-section="sidebar-widgets-footer-widget-4"].footer-widget-area-inner{text-align:left;}@media (max-width:921px){.footer-widget-area[data-section="sidebar-widgets-footer-widget-4"].footer-widget-area-inner{text-align:center;}}@media (max-width:544px){.footer-widget-area[data-section="sidebar-widgets-footer-widget-4"].footer-widget-area-inner{text-align:center;}}.footer-widget-area.widget-area.site-footer-focus-item{width:auto;}.ast-footer-row-inline .footer-widget-area.widget-area.site-footer-focus-item{width:100%;}.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"].footer-widget-area-inner a{color:var(--ast-global-color-5);}.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"].footer-widget-area-inner a:hover{color:var(--ast-global-color-0);}.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"]{display:block;}@media (max-width:921px){.ast-header-break-point .footer-widget-area[data-section="sidebar-widgets-footer-widget-1"]{display:block;}}@media (max-width:544px){.ast-header-break-point .footer-widget-area[data-section="sidebar-widgets-footer-widget-1"]{display:block;}}.footer-widget-area[data-section="sidebar-widgets-footer-widget-2"].footer-widget-area-inner a{color:var(--ast-global-color-5);}.footer-widget-area[data-section="sidebar-widgets-footer-widget-2"].footer-widget-area-inner a:hover{color:var(--ast-global-color-0);}.footer-widget-area[data-section="sidebar-widgets-footer-widget-2"]{display:block;}@media (max-width:921px){.ast-header-break-point .footer-widget-area[data-section="sidebar-widgets-footer-widget-2"]{display:block;}}@media (max-width:544px){.ast-header-break-point .footer-widget-area[data-section="sidebar-widgets-footer-widget-2"]{display:block;}}.footer-widget-area[data-section="sidebar-widgets-footer-widget-3"].footer-widget-area-inner a{color:var(--ast-global-color-5);}.footer-widget-area[data-section="sidebar-widgets-footer-widget-3"].footer-widget-area-inner a:hover{color:var(--ast-global-color-0);}.footer-widget-area[data-section="sidebar-widgets-footer-widget-3"]{display:block;}@media (max-width:921px){.ast-header-break-point .footer-widget-area[data-section="sidebar-widgets-footer-widget-3"]{display:block;}}@media (max-width:544px){.ast-header-break-point .footer-widget-area[data-section="sidebar-widgets-footer-widget-3"]{display:block;}}.footer-widget-area[data-section="sidebar-widgets-footer-widget-4"].footer-widget-area-inner{color:var(--ast-global-color-5);}.footer-widget-area[data-section="sidebar-widgets-footer-widget-4"].footer-widget-area-inner a{color:var(--ast-global-color-5);}.footer-widget-area[data-section="sidebar-widgets-footer-widget-4"].footer-widget-area-inner a:hover{color:var(--ast-global-color-1);}.footer-widget-area[data-section="sidebar-widgets-footer-widget-4"] .widget-title,.footer-widget-area[data-section="sidebar-widgets-footer-widget-4"] h1,.footer-widget-area[data-section="sidebar-widgets-footer-widget-4"] .widget-area h1,.footer-widget-area[data-section="sidebar-widgets-footer-widget-4"] h2,.footer-widget-area[data-section="sidebar-widgets-footer-widget-4"] .widget-area h2,.footer-widget-area[data-section="sidebar-widgets-footer-widget-4"] h3,.footer-widget-area[data-section="sidebar-widgets-footer-widget-4"] .widget-area h3,.footer-widget-area[data-section="sidebar-widgets-footer-widget-4"] h4,.footer-widget-area[data-section="sidebar-widgets-footer-widget-4"] .widget-area h4,.footer-widget-area[data-section="sidebar-widgets-footer-widget-4"] h5,.footer-widget-area[data-section="sidebar-widgets-footer-widget-4"] .widget-area h5,.footer-widget-area[data-section="sidebar-widgets-footer-widget-4"] h6,.footer-widget-area[data-section="sidebar-widgets-footer-widget-4"] .widget-area h6{color:var(--ast-global-color-5);}.footer-widget-area[data-section="sidebar-widgets-footer-widget-4"]{display:block;}@media (max-width:921px){.ast-header-break-point .footer-widget-area[data-section="sidebar-widgets-footer-widget-4"]{display:block;}}@media (max-width:544px){.ast-header-break-point .footer-widget-area[data-section="sidebar-widgets-footer-widget-4"]{display:block;}}.elementor-posts-container [CLASS*="ast-width-"]{width:100%;}.elementor-template-full-width .ast-container{display:block;}.elementor-screen-only,.screen-reader-text,.screen-reader-text span,.ui-helper-hidden-accessible{top:0 !important;}@media (max-width:544px){.elementor-element .elementor-wc-products .woocommerce[class*="columns-"] ul.products li.product{width:auto;margin:0;}.elementor-element .woocommerce .woocommerce-result-count{float:none;}}.ast-header-break-point .main-header-bar{border-bottom-width:1px;}@media (min-width:922px){.main-header-bar{border-bottom-width:1px;}}.main-header-menu .menu-item, #astra-footer-menu .menu-item, .main-header-bar .ast-masthead-custom-menu-items{-js-display:flex;display:flex;-webkit-box-pack:center;-webkit-justify-content:center;-moz-box-pack:center;-ms-flex-pack:center;justify-content:center;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;-moz-box-orient:vertical;-moz-box-direction:normal;-ms-flex-direction:column;flex-direction:column;}.main-header-menu > .menu-item > .menu-link, #astra-footer-menu > .menu-item > .menu-link{height:100%;-webkit-box-align:center;-webkit-align-items:center;-moz-box-align:center;-ms-flex-align:center;align-items:center;-js-display:flex;display:flex;}.ast-header-break-point .main-navigation ul .menu-item .menu-link .icon-arrow:first-of-type svg{top:.2em;margin-top:0px;margin-left:0px;width:.65em;transform:translate(0, -2px) rotateZ(270deg);}.ast-mobile-popup-content .ast-submenu-expanded > .ast-menu-toggle{transform:rotateX(180deg);overflow-y:auto;}@media (min-width:922px){.ast-builder-menu .main-navigation > ul > li:last-child a{margin-right:0;}}.ast-separate-container .ast-article-inner{background-color:var(--ast-global-color-5);background-image:none;}@media (max-width:921px){.ast-separate-container .ast-article-inner{background-color:var(--ast-global-color-5);background-image:none;}}@media (max-width:544px){.ast-separate-container .ast-article-inner{background-color:var(--ast-global-color-5);background-image:none;}}.ast-separate-container .ast-article-single:not(.ast-related-post), .ast-separate-container .error-404, .ast-separate-container .no-results, .single.ast-separate-container  .ast-author-meta, .ast-separate-container .related-posts-title-wrapper, .ast-separate-container .comments-count-wrapper, .ast-box-layout.ast-plain-container .site-content, .ast-padded-layout.ast-plain-container .site-content, .ast-separate-container .ast-archive-description, .ast-separate-container .comments-area .comment-respond, .ast-separate-container .comments-area .ast-comment-list li, .ast-separate-container .comments-area .comments-title{background-color:var(--ast-global-color-5);background-image:none;}@media (max-width:921px){.ast-separate-container .ast-article-single:not(.ast-related-post), .ast-separate-container .error-404, .ast-separate-container .no-results, .single.ast-separate-container  .ast-author-meta, .ast-separate-container .related-posts-title-wrapper, .ast-separate-container .comments-count-wrapper, .ast-box-layout.ast-plain-container .site-content, .ast-padded-layout.ast-plain-container .site-content, .ast-separate-container .ast-archive-description{background-color:var(--ast-global-color-5);background-image:none;}}@media (max-width:544px){.ast-separate-container .ast-article-single:not(.ast-related-post), .ast-separate-container .error-404, .ast-separate-container .no-results, .single.ast-separate-container  .ast-author-meta, .ast-separate-container .related-posts-title-wrapper, .ast-separate-container .comments-count-wrapper, .ast-box-layout.ast-plain-container .site-content, .ast-padded-layout.ast-plain-container .site-content, .ast-separate-container .ast-archive-description{background-color:var(--ast-global-color-5);background-image:none;}}.ast-separate-container.ast-two-container #secondary .widget{background-color:var(--ast-global-color-5);background-image:none;}@media (max-width:921px){.ast-separate-container.ast-two-container #secondary .widget{background-color:var(--ast-global-color-5);background-image:none;}}@media (max-width:544px){.ast-separate-container.ast-two-container #secondary .widget{background-color:var(--ast-global-color-5);background-image:none;}}.ast-mobile-header-content > *,.ast-desktop-header-content > * {padding: 10px 0;height: auto;}.ast-mobile-header-content > *:first-child,.ast-desktop-header-content > *:first-child {padding-top: 10px;}.ast-mobile-header-content > .ast-builder-menu,.ast-desktop-header-content > .ast-builder-menu {padding-top: 0;}.ast-mobile-header-content > *:last-child,.ast-desktop-header-content > *:last-child {padding-bottom: 0;}.ast-mobile-header-content .ast-search-menu-icon.ast-inline-search label,.ast-desktop-header-content .ast-search-menu-icon.ast-inline-search label {width: 100%;}.ast-desktop-header-content .main-header-bar-navigation .ast-submenu-expanded > .ast-menu-toggle::before {transform: rotateX(180deg);}#ast-desktop-header .ast-desktop-header-content,.ast-mobile-header-content .ast-search-icon,.ast-desktop-header-content .ast-search-icon,.ast-mobile-header-wrap .ast-mobile-header-content,.ast-main-header-nav-open.ast-popup-nav-open .ast-mobile-header-wrap .ast-mobile-header-content,.ast-main-header-nav-open.ast-popup-nav-open .ast-desktop-header-content {display: none;}.ast-main-header-nav-open.ast-header-break-point #ast-desktop-header .ast-desktop-header-content,.ast-main-header-nav-open.ast-header-break-point .ast-mobile-header-wrap .ast-mobile-header-content {display: block;}.ast-desktop .ast-desktop-header-content .astra-menu-animation-slide-up > .menu-item > .sub-menu,.ast-desktop .ast-desktop-header-content .astra-menu-animation-slide-up > .menu-item .menu-item > .sub-menu,.ast-desktop .ast-desktop-header-content .astra-menu-animation-slide-down > .menu-item > .sub-menu,.ast-desktop .ast-desktop-header-content .astra-menu-animation-slide-down > .menu-item .menu-item > .sub-menu,.ast-desktop .ast-desktop-header-content .astra-menu-animation-fade > .menu-item > .sub-menu,.ast-desktop .ast-desktop-header-content .astra-menu-animation-fade > .menu-item .menu-item > .sub-menu {opacity: 1;visibility: visible;}.ast-hfb-header.ast-default-menu-enable.ast-header-break-point .ast-mobile-header-wrap .ast-mobile-header-content .main-header-bar-navigation {width: unset;margin: unset;}.ast-mobile-header-content.content-align-flex-end .main-header-bar-navigation .menu-item-has-children > .ast-menu-toggle,.ast-desktop-header-content.content-align-flex-end .main-header-bar-navigation .menu-item-has-children > .ast-menu-toggle {left: calc( 20px - 0.907em);right: auto;}.ast-mobile-header-content .ast-search-menu-icon,.ast-mobile-header-content .ast-search-menu-icon.slide-search,.ast-desktop-header-content .ast-search-menu-icon,.ast-desktop-header-content .ast-search-menu-icon.slide-search {width: 100%;position: relative;display: block;right: auto;transform: none;}.ast-mobile-header-content .ast-search-menu-icon.slide-search .search-form,.ast-mobile-header-content .ast-search-menu-icon .search-form,.ast-desktop-header-content .ast-search-menu-icon.slide-search .search-form,.ast-desktop-header-content .ast-search-menu-icon .search-form {right: 0;visibility: visible;opacity: 1;position: relative;top: auto;transform: none;padding: 0;display: block;overflow: hidden;}.ast-mobile-header-content .ast-search-menu-icon.ast-inline-search .search-field,.ast-mobile-header-content .ast-search-menu-icon .search-field,.ast-desktop-header-content .ast-search-menu-icon.ast-inline-search .search-field,.ast-desktop-header-content .ast-search-menu-icon .search-field {width: 100%;padding-right: 5.5em;}.ast-mobile-header-content .ast-search-menu-icon .search-submit,.ast-desktop-header-content .ast-search-menu-icon .search-submit {display: block;position: absolute;height: 100%;top: 0;right: 0;padding: 0 1em;border-radius: 0;}.ast-hfb-header.ast-default-menu-enable.ast-header-break-point .ast-mobile-header-wrap .ast-mobile-header-content .main-header-bar-navigation ul .sub-menu .menu-link {padding-left: 30px;}.ast-hfb-header.ast-default-menu-enable.ast-header-break-point .ast-mobile-header-wrap .ast-mobile-header-content .main-header-bar-navigation .sub-menu .menu-item .menu-item .menu-link {padding-left: 40px;}.ast-mobile-popup-drawer.active .ast-mobile-popup-inner{background-color:#ffffff;;}.ast-mobile-header-wrap .ast-mobile-header-content, .ast-desktop-header-content{background-color:#ffffff;;}.ast-mobile-popup-content > *, .ast-mobile-header-content > *, .ast-desktop-popup-content > *, .ast-desktop-header-content > *{padding-top:0px;padding-bottom:0px;}.content-align-flex-start .ast-builder-layout-element{justify-content:flex-start;}.content-align-flex-start .main-header-menu{text-align:left;}.ast-mobile-popup-drawer.active .menu-toggle-close{color:#3a3a3a;}.ast-mobile-header-wrap .ast-primary-header-bar,.ast-primary-header-bar .site-primary-header-wrap{min-height:120px;}.ast-desktop .ast-primary-header-bar .main-header-menu > .menu-item{line-height:120px;}.ast-header-break-point #masthead .ast-mobile-header-wrap .ast-primary-header-bar,.ast-header-break-point #masthead .ast-mobile-header-wrap .ast-below-header-bar,.ast-header-break-point #masthead .ast-mobile-header-wrap .ast-above-header-bar{padding-left:20px;padding-right:20px;}.ast-header-break-point .ast-primary-header-bar{border-bottom-width:0px;border-bottom-color:var(--ast-global-color-0);border-bottom-style:solid;}@media (min-width:922px){.ast-primary-header-bar{border-bottom-width:0px;border-bottom-color:var(--ast-global-color-0);border-bottom-style:solid;}}.ast-primary-header-bar{background-color:#ffffff;background-image:none;}.ast-primary-header-bar{display:block;}@media (max-width:921px){.ast-header-break-point .ast-primary-header-bar{display:grid;}}@media (max-width:544px){.ast-header-break-point .ast-primary-header-bar{display:grid;}}[data-section="section-header-mobile-trigger"] .ast-button-wrap .ast-mobile-menu-trigger-minimal{color:var(--ast-global-color-0);border:none;background:transparent;}[data-section="section-header-mobile-trigger"] .ast-button-wrap .mobile-menu-toggle-icon .ast-mobile-svg{width:20px;height:20px;fill:var(--ast-global-color-0);}[data-section="section-header-mobile-trigger"] .ast-button-wrap .mobile-menu-wrap .mobile-menu{color:var(--ast-global-color-0);}.ast-builder-menu-mobile .main-navigation .menu-item.menu-item-has-children > .ast-menu-toggle{top:0;}.ast-builder-menu-mobile .main-navigation .menu-item-has-children > .menu-link:after{content:unset;}.ast-hfb-header .ast-builder-menu-mobile .main-header-menu, .ast-hfb-header .ast-builder-menu-mobile .main-navigation .menu-item .menu-link, .ast-hfb-header .ast-builder-menu-mobile .main-navigation .menu-item .sub-menu .menu-link{border-style:none;}.ast-builder-menu-mobile .main-navigation .menu-item.menu-item-has-children > .ast-menu-toggle{top:0;}@media (max-width:921px){.ast-builder-menu-mobile .main-navigation .menu-item.menu-item-has-children > .ast-menu-toggle{top:0;}.ast-builder-menu-mobile .main-navigation .menu-item-has-children > .menu-link:after{content:unset;}}@media (max-width:544px){.ast-builder-menu-mobile .main-navigation .menu-item.menu-item-has-children > .ast-menu-toggle{top:0;}}.ast-builder-menu-mobile .main-navigation{display:block;}@media (max-width:921px){.ast-header-break-point .ast-builder-menu-mobile .main-navigation{display:block;}}@media (max-width:544px){.ast-header-break-point .ast-builder-menu-mobile .main-navigation{display:block;}}:root{--e-global-color-astglobalcolor0:#3ea2ff;--e-global-color-astglobalcolor1:#0085ff;--e-global-color-astglobalcolor2:#0F172A;--e-global-color-astglobalcolor3:#364151;--e-global-color-astglobalcolor4:#E7F6FF;--e-global-color-astglobalcolor5:#FFFFFF;--e-global-color-astglobalcolor6:#D1DAE5;--e-global-color-astglobalcolor7:#070614;--e-global-color-astglobalcolor8:#222222;}
</style>
<link rel='stylesheet' id='astra-google-fonts-css' href='https://fonts.googleapis.com/css?family=Open+Sans%3A400%2C%7CMontserrat%3A700%2C%7CPoppins%3A500&#038;display=fallback&#038;ver=4.11.16' media='all' />
<link rel='stylesheet' id='hfe-widgets-style-css' href='https://cashflowpositif.com/wp-content/plugins/header-footer-elementor/inc/widgets-css/frontend.css?ver=2.7.0' media='all' />
<link rel='stylesheet' id='gum-elementor-addon-css' href='https://cashflowpositif.com/wp-content/plugins/gum-elementor-addon/css/style.css?ver=6.8.3' media='all' />
<link rel='stylesheet' id='jkit-elements-main-css' href='https://cashflowpositif.com/wp-content/plugins/jeg-elementor-kit/assets/css/elements/main.css?ver=3.0.1' media='all' />
<style id='wp-emoji-styles-inline-css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://cashflowpositif.com/wp-includes/css/dist/block-library/style.min.css?ver=6.8.3' media='all' />
<link rel='stylesheet' id='betterdocs-blocks-category-slate-layout-css' href='https://cashflowpositif.com/wp-content/plugins/betterdocs/assets/blocks/category-slate-layout/default.css?ver=4.2.6' media='all' />
<style id='global-styles-inline-css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--color--ast-global-color-0: var(--ast-global-color-0);--wp--preset--color--ast-global-color-1: var(--ast-global-color-1);--wp--preset--color--ast-global-color-2: var(--ast-global-color-2);--wp--preset--color--ast-global-color-3: var(--ast-global-color-3);--wp--preset--color--ast-global-color-4: var(--ast-global-color-4);--wp--preset--color--ast-global-color-5: var(--ast-global-color-5);--wp--preset--color--ast-global-color-6: var(--ast-global-color-6);--wp--preset--color--ast-global-color-7: var(--ast-global-color-7);--wp--preset--color--ast-global-color-8: var(--ast-global-color-8);--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:root { --wp--style--global--content-size: var(--wp--custom--ast-content-width-size);--wp--style--global--wide-size: var(--wp--custom--ast-wide-width-size); }:where(body) { margin: 0; }.wp-site-blocks > .alignleft { float: left; margin-right: 2em; }.wp-site-blocks > .alignright { float: right; margin-left: 2em; }.wp-site-blocks > .aligncenter { justify-content: center; margin-left: auto; margin-right: auto; }:where(.wp-site-blocks) > * { margin-block-start: 24px; margin-block-end: 0; }:where(.wp-site-blocks) > :first-child { margin-block-start: 0; }:where(.wp-site-blocks) > :last-child { margin-block-end: 0; }:root { --wp--style--block-gap: 24px; }:root :where(.is-layout-flow) > :first-child{margin-block-start: 0;}:root :where(.is-layout-flow) > :last-child{margin-block-end: 0;}:root :where(.is-layout-flow) > *{margin-block-start: 24px;margin-block-end: 0;}:root :where(.is-layout-constrained) > :first-child{margin-block-start: 0;}:root :where(.is-layout-constrained) > :last-child{margin-block-end: 0;}:root :where(.is-layout-constrained) > *{margin-block-start: 24px;margin-block-end: 0;}:root :where(.is-layout-flex){gap: 24px;}:root :where(.is-layout-grid){gap: 24px;}.is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}.is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}.is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}.is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}.is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}.is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}.is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}.is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}body{padding-top: 0px;padding-right: 0px;padding-bottom: 0px;padding-left: 0px;}a:where(:not(.wp-element-button)){text-decoration: none;}:root :where(.wp-element-button, .wp-block-button__link){background-color: #32373c;border-width: 0;color: #fff;font-family: inherit;font-size: inherit;line-height: inherit;padding: calc(0.667em + 2px) calc(1.333em + 2px);text-decoration: none;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-ast-global-color-0-color{color: var(--wp--preset--color--ast-global-color-0) !important;}.has-ast-global-color-1-color{color: var(--wp--preset--color--ast-global-color-1) !important;}.has-ast-global-color-2-color{color: var(--wp--preset--color--ast-global-color-2) !important;}.has-ast-global-color-3-color{color: var(--wp--preset--color--ast-global-color-3) !important;}.has-ast-global-color-4-color{color: var(--wp--preset--color--ast-global-color-4) !important;}.has-ast-global-color-5-color{color: var(--wp--preset--color--ast-global-color-5) !important;}.has-ast-global-color-6-color{color: var(--wp--preset--color--ast-global-color-6) !important;}.has-ast-global-color-7-color{color: var(--wp--preset--color--ast-global-color-7) !important;}.has-ast-global-color-8-color{color: var(--wp--preset--color--ast-global-color-8) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-ast-global-color-0-background-color{background-color: var(--wp--preset--color--ast-global-color-0) !important;}.has-ast-global-color-1-background-color{background-color: var(--wp--preset--color--ast-global-color-1) !important;}.has-ast-global-color-2-background-color{background-color: var(--wp--preset--color--ast-global-color-2) !important;}.has-ast-global-color-3-background-color{background-color: var(--wp--preset--color--ast-global-color-3) !important;}.has-ast-global-color-4-background-color{background-color: var(--wp--preset--color--ast-global-color-4) !important;}.has-ast-global-color-5-background-color{background-color: var(--wp--preset--color--ast-global-color-5) !important;}.has-ast-global-color-6-background-color{background-color: var(--wp--preset--color--ast-global-color-6) !important;}.has-ast-global-color-7-background-color{background-color: var(--wp--preset--color--ast-global-color-7) !important;}.has-ast-global-color-8-background-color{background-color: var(--wp--preset--color--ast-global-color-8) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-ast-global-color-0-border-color{border-color: var(--wp--preset--color--ast-global-color-0) !important;}.has-ast-global-color-1-border-color{border-color: var(--wp--preset--color--ast-global-color-1) !important;}.has-ast-global-color-2-border-color{border-color: var(--wp--preset--color--ast-global-color-2) !important;}.has-ast-global-color-3-border-color{border-color: var(--wp--preset--color--ast-global-color-3) !important;}.has-ast-global-color-4-border-color{border-color: var(--wp--preset--color--ast-global-color-4) !important;}.has-ast-global-color-5-border-color{border-color: var(--wp--preset--color--ast-global-color-5) !important;}.has-ast-global-color-6-border-color{border-color: var(--wp--preset--color--ast-global-color-6) !important;}.has-ast-global-color-7-border-color{border-color: var(--wp--preset--color--ast-global-color-7) !important;}.has-ast-global-color-8-border-color{border-color: var(--wp--preset--color--ast-global-color-8) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
:root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='popb_admin_top_menu_styles_csm-css' href='https://cashflowpositif.com/wp-content/plugins/page-builder-add/styles/admin-csm-menu-styles.css?ver=6.8.3' media='all' />
<link rel='stylesheet' id='eae-css-css' href='https://cashflowpositif.com/wp-content/plugins/addon-elements-for-elementor-page-builder/assets/css/eae.min.css?ver=1.14.3' media='all' />
<link rel='stylesheet' id='eae-peel-css-css' href='https://cashflowpositif.com/wp-content/plugins/addon-elements-for-elementor-page-builder/assets/lib/peel/peel.css?ver=1.14.3' media='all' />
<link rel='stylesheet' id='font-awesome-4-shim-css' href='https://cashflowpositif.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/v4-shims.min.css?ver=1.0' media='all' />
<link rel='stylesheet' id='font-awesome-5-all-css' href='https://cashflowpositif.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/all.min.css?ver=1.0' media='all' />
<link rel='stylesheet' id='vegas-css-css' href='https://cashflowpositif.com/wp-content/plugins/addon-elements-for-elementor-page-builder/assets/lib/vegas/vegas.min.css?ver=2.4.0' media='all' />
<link rel='stylesheet' id='hfe-style-css' href='https://cashflowpositif.com/wp-content/plugins/header-footer-elementor/assets/css/header-footer-elementor.css?ver=2.7.0' media='all' />
<link rel='stylesheet' id='elementor-frontend-css' href='https://cashflowpositif.com/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.33.2' media='all' />
<style id='elementor-frontend-inline-css'>
.elementor-kit-10841{--e-global-color-primary:#6EC1E4;--e-global-color-secondary:#54595F;--e-global-color-text:#7A7A7A;--e-global-color-accent:#61CE70;--e-global-typography-primary-font-family:"Roboto";--e-global-typography-primary-font-weight:600;--e-global-typography-secondary-font-family:"Roboto Slab";--e-global-typography-secondary-font-weight:400;--e-global-typography-text-font-family:"Roboto";--e-global-typography-text-font-weight:400;--e-global-typography-accent-font-family:"Roboto";--e-global-typography-accent-font-weight:500;}.elementor-kit-10841 e-page-transition{background-color:#FFBC7D;}.elementor-section.elementor-section-boxed > .elementor-container{max-width:1140px;}.e-con{--container-max-width:1140px;}.elementor-widget:not(:last-child){margin-block-end:20px;}.elementor-element{--widgets-spacing:20px 20px;--widgets-spacing-row:20px;--widgets-spacing-column:20px;}{}h1.entry-title{display:var(--page-title-display);}@media(max-width:1024px){.elementor-section.elementor-section-boxed > .elementor-container{max-width:1024px;}.e-con{--container-max-width:1024px;}}@media(max-width:767px){.elementor-section.elementor-section-boxed > .elementor-container{max-width:767px;}.e-con{--container-max-width:767px;}}
</style>
<link rel='stylesheet' id='cute-alert-css' href='https://cashflowpositif.com/wp-content/plugins/metform/public/assets/lib/cute-alert/style.css?ver=4.0.8' media='all' />
<link rel='stylesheet' id='text-editor-style-css' href='https://cashflowpositif.com/wp-content/plugins/metform/public/assets/css/text-editor.css?ver=4.0.8' media='all' />
<link rel='stylesheet' id='tablepress-default-css' href='https://cashflowpositif.com/wp-content/tablepress-combined.min.css?ver=95' media='all' />
<link rel='stylesheet' id='hfe-elementor-icons-css' href='https://cashflowpositif.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.34.0' media='all' />
<link rel='stylesheet' id='hfe-icons-list-css' href='https://cashflowpositif.com/wp-content/plugins/elementor/assets/css/widget-icon-list.min.css?ver=3.24.3' media='all' />
<link rel='stylesheet' id='hfe-social-icons-css' href='https://cashflowpositif.com/wp-content/plugins/elementor/assets/css/widget-social-icons.min.css?ver=3.24.0' media='all' />
<link rel='stylesheet' id='hfe-social-share-icons-brands-css' href='https://cashflowpositif.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.css?ver=5.15.3' media='all' />
<link rel='stylesheet' id='hfe-social-share-icons-fontawesome-css' href='https://cashflowpositif.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.css?ver=5.15.3' media='all' />
<link rel='stylesheet' id='hfe-nav-menu-icons-css' href='https://cashflowpositif.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.css?ver=5.15.3' media='all' />
<link rel='stylesheet' id='hfe-widget-blockquote-css' href='https://cashflowpositif.com/wp-content/plugins/elementor-pro/assets/css/widget-blockquote.min.css?ver=3.25.0' media='all' />
<link rel='stylesheet' id='hfe-mega-menu-css' href='https://cashflowpositif.com/wp-content/plugins/elementor-pro/assets/css/widget-mega-menu.min.css?ver=3.26.2' media='all' />
<link rel='stylesheet' id='hfe-nav-menu-widget-css' href='https://cashflowpositif.com/wp-content/plugins/elementor-pro/assets/css/widget-nav-menu.min.css?ver=3.26.0' media='all' />
<link rel='stylesheet' id='ekit-widget-styles-css' href='https://cashflowpositif.com/wp-content/plugins/elementskit-lite/widgets/init/assets/css/widget-styles.css?ver=3.7.6' media='all' />
<link rel='stylesheet' id='ekit-responsive-css' href='https://cashflowpositif.com/wp-content/plugins/elementskit-lite/widgets/init/assets/css/responsive.css?ver=3.7.6' media='all' />
<link rel='stylesheet' id='elementor-gf-local-roboto-css' href='https://cashflowpositif.com/wp-content/uploads/elementor/google-fonts/css/roboto.css?ver=1742248414' media='all' />
<link rel='stylesheet' id='elementor-gf-local-robotoslab-css' href='https://cashflowpositif.com/wp-content/uploads/elementor/google-fonts/css/robotoslab.css?ver=1742248416' media='all' />
<script defer='defer' src="https://cashflowpositif.com/wp-content/themes/astra/assets/js/minified/flexibility.min.js?ver=4.11.16" id="astra-flexibility-js"></script>
<script id="astra-flexibility-js-after">
flexibility(document.documentElement);
</script>
<script defer='defer' src="https://cashflowpositif.com/wp-content/plugins/addon-elements-for-elementor-page-builder/assets/js/iconHelper.js?ver=1.0" id="eae-iconHelper-js"></script>
<script src="https://cashflowpositif.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script defer='defer' src="https://cashflowpositif.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script id="jquery-js-after">
!function($){"use strict";$(document).ready(function(){$(this).scrollTop()>100&&$(".hfe-scroll-to-top-wrap").removeClass("hfe-scroll-to-top-hide"),$(window).scroll(function(){$(this).scrollTop()<100?$(".hfe-scroll-to-top-wrap").fadeOut(300):$(".hfe-scroll-to-top-wrap").fadeIn(300)}),$(".hfe-scroll-to-top-wrap").on("click",function(){$("html, body").animate({scrollTop:0},300);return!1})})}(jQuery);
!function($){'use strict';$(document).ready(function(){var bar=$('.hfe-reading-progress-bar');if(!bar.length)return;$(window).on('scroll',function(){var s=$(window).scrollTop(),d=$(document).height()-$(window).height(),p=d? s/d*100:0;bar.css('width',p+'%')});});}(jQuery);
</script>
<link rel="https://api.w.org/" href="https://cashflowpositif.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://cashflowpositif.com/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.8.3" />

		<!-- GA Google Analytics @ https://m0n.co/ga -->
		<script async src="https://www.googletagmanager.com/gtag/js?id=G-413ZQSY7BL"></script>
		<script>
			window.dataLayer = window.dataLayer || [];
			function gtag(){dataLayer.push(arguments);}
			gtag('js', new Date());
			gtag('config', 'G-413ZQSY7BL');
		</script>

	<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NVBLHJT');</script>
<!-- End Google Tag Manager --><meta name="ti-site-data" content="eyJyIjoiMTowITc6MCEzMDowIiwibyI6Imh0dHBzOlwvXC9jYXNoZmxvd3Bvc2l0aWYuY29tXC93cC1hZG1pblwvYWRtaW4tYWpheC5waHA/YWN0aW9uPXRpX29ubGluZV91c2Vyc19nb29nbGUmYW1wO3A9JTJGc2lnbmFscyUyRml3bC5qcyZhbXA7X3dwbm9uY2U9ZTI5NGUzOTE0MiJ9" /><meta name="generator" content="Elementor 3.33.2; features: e_font_icon_svg, additional_custom_breakpoints; settings: css_print_method-internal, google_font-enabled, font_display-swap">
			<style>
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload),
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload) * {
					background-image: none !important;
				}
				@media screen and (max-height: 1024px) {
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
				@media screen and (max-height: 640px) {
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
			</style>
			<link rel="icon" href="https://cashflowpositif.com/wp-content/uploads/2024/06/cropped-Trouvez-un-investissement-immobilier-rentable-en-temps-de-crise-12-32x32.png" sizes="32x32" />
<link rel="icon" href="https://cashflowpositif.com/wp-content/uploads/2024/06/cropped-Trouvez-un-investissement-immobilier-rentable-en-temps-de-crise-12-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://cashflowpositif.com/wp-content/uploads/2024/06/cropped-Trouvez-un-investissement-immobilier-rentable-en-temps-de-crise-12-180x180.png" />
<meta name="msapplication-TileImage" content="https://cashflowpositif.com/wp-content/uploads/2024/06/cropped-Trouvez-un-investissement-immobilier-rentable-en-temps-de-crise-12-270x270.png" />
		<style id="wp-custom-css">
			

/** Start Block Kit CSS: 144-3-3a7d335f39a8579c20cdf02f8d462582 **/

.envato-block__preview{overflow: visible;}

/* Envato Kit 141 Custom Styles - Applied to the element under Advanced */

.elementor-headline-animation-type-drop-in .elementor-headline-dynamic-wrapper{
	text-align: center;
}
.envato-kit-141-top-0 h1,
.envato-kit-141-top-0 h2,
.envato-kit-141-top-0 h3,
.envato-kit-141-top-0 h4,
.envato-kit-141-top-0 h5,
.envato-kit-141-top-0 h6,
.envato-kit-141-top-0 p {
	margin-top: 0;
}

.envato-kit-141-newsletter-inline .elementor-field-textual.elementor-size-md {
	padding-left: 1.5rem;
	padding-right: 1.5rem;
}

.envato-kit-141-bottom-0 p {
	margin-bottom: 0;
}

.envato-kit-141-bottom-8 .elementor-price-list .elementor-price-list-item .elementor-price-list-header {
	margin-bottom: .5rem;
}

.envato-kit-141.elementor-widget-testimonial-carousel.elementor-pagination-type-bullets .swiper-container {
	padding-bottom: 52px;
}

.envato-kit-141-display-inline {
	display: inline-block;
}

.envato-kit-141 .elementor-slick-slider ul.slick-dots {
	bottom: -40px;
}

/** End Block Kit CSS: 144-3-3a7d335f39a8579c20cdf02f8d462582 **/



/** Start Block Kit CSS: 105-3-0fb64e69c49a8e10692d28840c54ef95 **/

.envato-kit-102-phone-overlay {
	position: absolute !important;
	display: block !important;
	top: 0%;
	left: 0%;
	right: 0%;
	margin: auto;
	z-index: 1;
}

/** End Block Kit CSS: 105-3-0fb64e69c49a8e10692d28840c54ef95 **/



/** Start Block Kit CSS: 143-3-7969bb877702491bc5ca272e536ada9d **/

.envato-block__preview{overflow: visible;}
/* Material Button Click Effect */
.envato-kit-140-material-hit .menu-item a,
.envato-kit-140-material-button .elementor-button{
  background-position: center;
  transition: background 0.8s;
}
.envato-kit-140-material-hit .menu-item a:hover,
.envato-kit-140-material-button .elementor-button:hover{
  background: radial-gradient(circle, transparent 1%, #fff 1%) center/15000%;
}
.envato-kit-140-material-hit .menu-item a:active,
.envato-kit-140-material-button .elementor-button:active{
  background-color: #FFF;
  background-size: 100%;
  transition: background 0s;
}

/* Field Shadow */
.envato-kit-140-big-shadow-form .elementor-field-textual{
	box-shadow: 0 20px 30px rgba(0,0,0, .05);
}

/* FAQ */
.envato-kit-140-faq .elementor-accordion .elementor-accordion-item{
	border-width: 0 0 1px !important;
}

/* Scrollable Columns */
.envato-kit-140-scrollable{
	 height: 100%;
   overflow: auto;
   overflow-x: hidden;
}

/* ImageBox: No Space */
.envato-kit-140-imagebox-nospace:hover{
	transform: scale(1.1);
	transition: all 0.3s;
}
.envato-kit-140-imagebox-nospace figure{
	line-height: 0;
}

.envato-kit-140-slide .elementor-slide-content{
	background: #FFF;
	margin-left: -60px;
	padding: 1em;
}
.envato-kit-140-carousel .slick-active:not(.slick-current)  img{
	padding: 20px !important;
	transition: all .9s;
}

/** End Block Kit CSS: 143-3-7969bb877702491bc5ca272e536ada9d **/



/** Start Block Kit CSS: 136-3-fc37602abad173a9d9d95d89bbe6bb80 **/

.envato-block__preview{overflow: visible !important;}

/** End Block Kit CSS: 136-3-fc37602abad173a9d9d95d89bbe6bb80 **/

.pum-overlay {
  background-color: rgba(0, 0, 0, 0.6) !important;
}


/* Centrage du popup */
.pum-container {
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
}

/* Style du fond noir transparent */
.pum-overlay {
  background: rgba(0, 0, 0, 0.75) !important;
}

/* Style du contenu */
.popup-offre-container {
  font-family: 'Poppins', sans-serif;
  text-align: center;
  max-width: 380px;
  background: #fff;
  border-radius: 16px;
  padding-bottom: 24px;
  overflow: hidden;
}

/* Image */
.popup-offre-container img {
  display: block;
  width: 100%;
  height: auto;
  border-radius: 16px 16px 0 0;
}

/* Texte */
.popup-offre-container p {
  margin: 18px 24px 0;
  font-size: 14px;
  font-weight: 500;
  color: #111;
  line-height: 1.4;
}

/* Texte en bleu */
.popup-offre-container .accent {
  color: #284A9A;
  font-weight: 600;
}

/* Bouton CTA */
.popup-offre-container .cta {
  margin: 16px auto 0;
  background: #284A9A;
  color: white;
  padding: 14px 28px;
  font-weight: 600;
  font-size: 15px;
  text-decoration: none;
  border-radius: 8px;
  display: inline-block;
  box-shadow: none;
  border: none;
}

/* Pas de hover moche */
.popup-offre-container .cta:hover {
  opacity: 0.95;
  background: #284A9A;
}

/* Croix de fermeture custom */
.popup-close {
  top: 16px !important;
  right: 16px !important;
  background: white;
  color: black !important;
  border-radius: 50%;
  font-size: 18px !important;
  font-weight: bold;
  width: 32px;
  height: 32px;
  display: flex;
  justify-content: center;
  align-items: center;
  box-shadow: 0 0 4px rgba(0, 0, 0, 0.2);
}
		</style>
		</head>

<body itemtype='https://schema.org/WebPage' itemscope='itemscope' class="error404 wp-custom-logo wp-embed-responsive wp-theme-astra wp-child-theme-astra-child ehf-template-astra ehf-stylesheet-astra-child jkit-color-scheme ast-desktop ast-separate-container ast-two-container ast-no-sidebar astra-4.11.16 group-blog ast-replace-site-logo-transparent ast-inherit-site-logo-transparent ast-hfb-header elementor-default elementor-kit-10841">
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NVBLHJT"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<a
	class="skip-link screen-reader-text"
	href="#content">
		Aller au contenu</a>

<div
class="hfeed site" id="page">
			<header
		class="site-header header-main-layout-1 ast-primary-menu-enabled ast-logo-title-inline ast-hide-custom-menu-mobile ast-builder-menu-toggle-icon ast-mobile-header-inline" id="masthead" itemtype="https://schema.org/WPHeader" itemscope="itemscope" itemid="#masthead"		>
			<div id="ast-desktop-header" data-toggle-type="dropdown">
		<div class="ast-main-header-wrap main-header-bar-wrap ">
		<div class="ast-primary-header-bar ast-primary-header main-header-bar site-header-focus-item" data-section="section-primary-header-builder">
						<div class="site-primary-header-wrap ast-builder-grid-row-container site-header-focus-item ast-container" data-section="section-primary-header-builder">
				<div class="ast-builder-grid-row ast-builder-grid-row-has-sides ast-builder-grid-row-no-center">
											<div class="site-header-primary-section-left site-header-section ast-flex site-header-section-left">
									<div class="ast-builder-layout-element ast-flex site-header-focus-item" data-section="title_tagline">
							<div
				class="site-branding ast-site-identity" itemtype="https://schema.org/Organization" itemscope="itemscope"				>
					<span class="site-logo-img"><a href="https://cashflowpositif.com/" class="custom-logo-link" rel="home"><img width="158" height="53" src="https://cashflowpositif.com/wp-content/uploads/2024/06/cropped-Trouvez-un-investissement-immobilier-rentable-en-temps-de-crise-13-158x53.png" class="custom-logo" alt="Cash Flow Positif" decoding="async" srcset="https://cashflowpositif.com/wp-content/uploads/2024/06/cropped-Trouvez-un-investissement-immobilier-rentable-en-temps-de-crise-13-158x53.png 158w, https://cashflowpositif.com/wp-content/uploads/2024/06/cropped-Trouvez-un-investissement-immobilier-rentable-en-temps-de-crise-13-300x100.png 300w, https://cashflowpositif.com/wp-content/uploads/2024/06/cropped-Trouvez-un-investissement-immobilier-rentable-en-temps-de-crise-13-1024x341.png 1024w, https://cashflowpositif.com/wp-content/uploads/2024/06/cropped-Trouvez-un-investissement-immobilier-rentable-en-temps-de-crise-13-768x256.png 768w, https://cashflowpositif.com/wp-content/uploads/2024/06/cropped-Trouvez-un-investissement-immobilier-rentable-en-temps-de-crise-13.png 1080w" sizes="(max-width: 158px) 100vw, 158px" /></a></span>				</div>
			<!-- .site-branding -->
					</div>
								</div>
																								<div class="site-header-primary-section-right site-header-section ast-flex ast-grid-right-section">
										<div class="ast-builder-menu-1 ast-builder-menu ast-flex ast-builder-menu-1-focus-item ast-builder-layout-element site-header-focus-item" data-section="section-hb-menu-1">
			<div class="ast-main-header-bar-alignment"><div class="main-header-bar-navigation"><nav class="site-navigation ast-flex-grow-1 navigation-accessibility site-header-focus-item" id="primary-site-navigation-desktop" aria-label="Navigation principale du site" itemtype="https://schema.org/SiteNavigationElement" itemscope="itemscope"><div class="main-navigation ast-inline-flex"><ul id="ast-hf-menu-1" class="main-header-menu ast-menu-shadow ast-nav-menu ast-flex  submenu-with-border stack-on-mobile"><li id="menu-item-20" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20"><a href="https://cashflowpositif.com/projects/" class="menu-link">Réalisations</a></li>
<li id="menu-item-17" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-17"><a href="https://cashflowpositif.com/equipe-cash-flow-positif/" class="menu-link">Équipe</a></li>
<li id="menu-item-18" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18"><a href="https://cashflowpositif.com/about/" class="menu-link">Tarifs</a></li>
<li id="menu-item-1567" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-1567"><a href="https://cashflowpositif.com/articles/" class="menu-link">Ressources</a></li>
<li id="menu-item-5847" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-5847"><a target="_blank" href="https://go.cashflowpositif.com/simulation" class="menu-link">Simulation</a></li>
</ul></div></nav></div></div>		</div>
				<div class="ast-builder-layout-element ast-flex site-header-focus-item ast-header-button-1" data-section="section-hb-button-1">
			<div class="ast-builder-button-wrap ast-builder-button-size-"><a class="ast-custom-button-link" href="https://go.cashflowpositif.com/opportunity/" target="_self"  role="button" aria-label="Découvrir nos biens" >
				<div class="ast-custom-button">Découvrir nos biens</div>
			</a><a class="menu-link" href="https://go.cashflowpositif.com/opportunity/" target="_self" >Découvrir nos biens</a></div>		</div>
									</div>
												</div>
					</div>
								</div>
			</div>
	</div> <!-- Main Header Bar Wrap -->
<div id="ast-mobile-header" class="ast-mobile-header-wrap " data-type="dropdown">
		<div class="ast-main-header-wrap main-header-bar-wrap" >
		<div class="ast-primary-header-bar ast-primary-header main-header-bar site-primary-header-wrap site-header-focus-item ast-builder-grid-row-layout-default ast-builder-grid-row-tablet-layout-default ast-builder-grid-row-mobile-layout-default" data-section="section-primary-header-builder">
									<div class="ast-builder-grid-row ast-builder-grid-row-has-sides ast-builder-grid-row-no-center">
													<div class="site-header-primary-section-left site-header-section ast-flex site-header-section-left">
										<div class="ast-builder-layout-element ast-flex site-header-focus-item" data-section="title_tagline">
							<div
				class="site-branding ast-site-identity" itemtype="https://schema.org/Organization" itemscope="itemscope"				>
					<span class="site-logo-img"><a href="https://cashflowpositif.com/" class="custom-logo-link" rel="home"><img width="158" height="53" src="https://cashflowpositif.com/wp-content/uploads/2024/06/cropped-Trouvez-un-investissement-immobilier-rentable-en-temps-de-crise-13-158x53.png" class="custom-logo" alt="Cash Flow Positif" decoding="async" srcset="https://cashflowpositif.com/wp-content/uploads/2024/06/cropped-Trouvez-un-investissement-immobilier-rentable-en-temps-de-crise-13-158x53.png 158w, https://cashflowpositif.com/wp-content/uploads/2024/06/cropped-Trouvez-un-investissement-immobilier-rentable-en-temps-de-crise-13-300x100.png 300w, https://cashflowpositif.com/wp-content/uploads/2024/06/cropped-Trouvez-un-investissement-immobilier-rentable-en-temps-de-crise-13-1024x341.png 1024w, https://cashflowpositif.com/wp-content/uploads/2024/06/cropped-Trouvez-un-investissement-immobilier-rentable-en-temps-de-crise-13-768x256.png 768w, https://cashflowpositif.com/wp-content/uploads/2024/06/cropped-Trouvez-un-investissement-immobilier-rentable-en-temps-de-crise-13.png 1080w" sizes="(max-width: 158px) 100vw, 158px" /></a></span>				</div>
			<!-- .site-branding -->
					</div>
									</div>
																									<div class="site-header-primary-section-right site-header-section ast-flex ast-grid-right-section">
										<div class="ast-builder-layout-element ast-flex site-header-focus-item" data-section="section-header-mobile-trigger">
						<div class="ast-button-wrap">
				<button type="button" class="menu-toggle main-header-menu-toggle ast-mobile-menu-trigger-minimal"   aria-expanded="false" aria-label="Main menu toggle">
					<span class="screen-reader-text">Main Menu</span>
					<span class="mobile-menu-toggle-icon">
						<span aria-hidden="true" class="ahfb-svg-iconset ast-inline-flex svg-baseline"><svg class='ast-mobile-svg ast-menu-svg' fill='currentColor' version='1.1' xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'><path d='M3 13h18c0.552 0 1-0.448 1-1s-0.448-1-1-1h-18c-0.552 0-1 0.448-1 1s0.448 1 1 1zM3 7h18c0.552 0 1-0.448 1-1s-0.448-1-1-1h-18c-0.552 0-1 0.448-1 1s0.448 1 1 1zM3 19h18c0.552 0 1-0.448 1-1s-0.448-1-1-1h-18c-0.552 0-1 0.448-1 1s0.448 1 1 1z'></path></svg></span><span aria-hidden="true" class="ahfb-svg-iconset ast-inline-flex svg-baseline"><svg class='ast-mobile-svg ast-close-svg' fill='currentColor' version='1.1' xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'><path d='M5.293 6.707l5.293 5.293-5.293 5.293c-0.391 0.391-0.391 1.024 0 1.414s1.024 0.391 1.414 0l5.293-5.293 5.293 5.293c0.391 0.391 1.024 0.391 1.414 0s0.391-1.024 0-1.414l-5.293-5.293 5.293-5.293c0.391-0.391 0.391-1.024 0-1.414s-1.024-0.391-1.414 0l-5.293 5.293-5.293-5.293c-0.391-0.391-1.024-0.391-1.414 0s-0.391 1.024 0 1.414z'></path></svg></span>					</span>
									</button>
			</div>
					</div>
									</div>
											</div>
						</div>
	</div>
				<div class="ast-mobile-header-content content-align-flex-start ">
						<div class="ast-builder-menu-mobile ast-builder-menu ast-builder-menu-mobile-focus-item ast-builder-layout-element site-header-focus-item" data-section="section-header-mobile-menu">
			<div class="ast-main-header-bar-alignment"><div class="main-header-bar-navigation"><nav class="site-navigation ast-flex-grow-1 navigation-accessibility site-header-focus-item" id="ast-mobile-site-navigation" aria-label="Navigation du site : MAIN MENU" itemtype="https://schema.org/SiteNavigationElement" itemscope="itemscope"><div class="main-navigation"><ul id="ast-hf-mobile-menu" class="main-header-menu ast-nav-menu ast-flex  submenu-with-border astra-menu-animation-fade  stack-on-mobile"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20"><a href="https://cashflowpositif.com/projects/" class="menu-link">Réalisations</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-17"><a href="https://cashflowpositif.com/equipe-cash-flow-positif/" class="menu-link">Équipe</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18"><a href="https://cashflowpositif.com/about/" class="menu-link">Tarifs</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-1567"><a href="https://cashflowpositif.com/articles/" class="menu-link">Ressources</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-5847"><a target="_blank" href="https://go.cashflowpositif.com/simulation" class="menu-link">Simulation</a></li>
</ul></div></nav></div></div>		</div>
					</div>
			</div>
		</header><!-- #masthead -->
			<div id="content" class="site-content">
		<div class="ast-container">
		

	<div id="primary" class="content-area primary">

		
		

<section class="error-404 not-found">

		<div class="ast-breadcrumbs-wrapper">
		<div class="ast-breadcrumbs-inner">
			<nav role="navigation" aria-label="Breadcrumbs" class="breadcrumb-trail breadcrumbs"><div class="ast-breadcrumbs"><ul class="trail-items"><li class="trail-item trail-begin"><span><a href="https://cashflowpositif.com/" rel="home"><span>Accueil</span></a></span></li><li class="trail-item trail-end"><span><span>404 - Introuvable</span></span></li></ul></div></nav>		</div>
	</div>
	
	<div class="ast-404-layout-1" >

	<header class="page-header"><h1 class="page-title">Cette page ne semble pas exister.</h1></header><!-- .page-header -->
	<div class="page-content">

		<div class="page-sub-title">
			Il semble que le lien pointant ici soit défectueux. Et si vous essayiez plutôt de rechercher ?		</div>

		<div class="ast-404-search">
			<div class="widget widget_search"><form role="search" method="get" class="search-form" action="https://cashflowpositif.com/">
	<label for="search-field">
		<span class="screen-reader-text">Rechercher :</span>
		<input type="search" id="search-field" class="search-field"   placeholder="Recherche…" value="" name="s" tabindex="-1">
					<button class="search-submit ast-search-submit" aria-label="Envoi de la recherche">
				<span hidden>Rechercher</span>
				<i><span class="ast-icon icon-search"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="-893 477 142 142" enable-background="new -888 480 142 142" xml:space="preserve">
						  <path d="M-787.4,568.7h-6.3l-2.4-2.4c7.9-8.7,12.6-20.5,12.6-33.1c0-28.4-22.9-51.3-51.3-51.3  c-28.4,0-51.3,22.9-51.3,51.3c0,28.4,22.9,51.3,51.3,51.3c12.6,0,24.4-4.7,33.1-12.6l2.4,2.4v6.3l39.4,39.4l11.8-11.8L-787.4,568.7  L-787.4,568.7z M-834.7,568.7c-19.7,0-35.5-15.8-35.5-35.5c0-19.7,15.8-35.5,35.5-35.5c19.7,0,35.5,15.8,35.5,35.5  C-799.3,553-815,568.7-834.7,568.7L-834.7,568.7z" />
						  </svg></span></i>
			</button>
			</label>
			<input type="submit" class="search-submit" value="Rechercher">
	</form>
</div>		</div>

	</div><!-- .page-content -->
</div>

	
</section><!-- .error-404 -->

		

		
	</div><!-- #primary -->


	</div> <!-- ast-container -->
	</div><!-- #content -->
<footer
class="site-footer" id="colophon" itemtype="https://schema.org/WPFooter" itemscope="itemscope" itemid="#colophon">
			<div class="site-primary-footer-wrap ast-builder-grid-row-container site-footer-focus-item ast-builder-grid-row-5-equal ast-builder-grid-row-tablet-5-equal ast-builder-grid-row-mobile-full ast-footer-row-stack ast-footer-row-tablet-stack ast-footer-row-mobile-stack" data-section="section-primary-footer-builder">
	<div class="ast-builder-grid-row-container-inner">
					<div class="ast-builder-footer-grid-columns site-primary-footer-inner-wrap ast-builder-grid-row">
											<div class="site-footer-primary-section-1 site-footer-section site-footer-section-1">
							<aside
		class="footer-widget-area widget-area site-footer-focus-item footer-widget-area-inner" data-section="sidebar-widgets-footer-widget-1" aria-label="Footer Widget 1" role="region"				>
			<section id="block-7" class="widget widget_block">
<h5 class="wp-block-heading has-text-align-left has-text-color" style="color:#ffffff">À PROPOS</h5>
</section><section id="block-8" class="widget widget_block widget_text">
<p class="has-text-color" style="color:#ffffff"></p>
</section><section id="nav_menu-3" class="widget widget_nav_menu"><nav class="menu-a-propos-container" aria-label="Menu"><ul id="menu-a-propos" class="menu"><li id="menu-item-1272" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1272"><a href="https://cashflowpositif.com/mentions-legales/" class="menu-link">Mentions légales</a></li>
<li id="menu-item-1270" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1270"><a href="https://cashflowpositif.com/confidentialite-2/" class="menu-link">Confidentialité</a></li>
<li id="menu-item-1271" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1271"><a href="https://cashflowpositif.com/conditions-generales-utilisation/" class="menu-link">Conditions générales d&rsquo;utilisation</a></li>
<li id="menu-item-1339" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1339"><a href="https://cashflowpositif.com/conditions-generales-vente/" class="menu-link">Conditions générales de vente</a></li>
<li id="menu-item-5943" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5943"><a href="https://cashflowpositif.com/vos-donnees-personnelles/" class="menu-link">Contacter DPO</a></li>
</ul></nav></section>		</aside>
						</div>
											<div class="site-footer-primary-section-2 site-footer-section site-footer-section-2">
							<aside
		class="footer-widget-area widget-area site-footer-focus-item footer-widget-area-inner" data-section="sidebar-widgets-footer-widget-3" aria-label="Footer Widget 3" role="region"		>
			<section id="block-11" class="widget widget_block">
<h5 class="wp-block-heading has-text-color" style="color:#ffffff">NOS SERVICES</h5>
</section><section id="block-13" class="widget widget_block">
<ul style="color:#ffffff" class="has-text-color wp-block-list">
<li></li>
</ul>
</section><section id="nav_menu-4" class="widget widget_nav_menu"><nav class="menu-nos-services-container" aria-label="Menu"><ul id="menu-nos-services" class="menu"><li id="menu-item-913" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-913"><a href="https://cashflowpositif.com/partner/" class="menu-link">Devenir partenaire</a></li>
<li id="menu-item-8532" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-8532"><a href="https://cashflowpositif.com/investissement-locatif-avenir/" class="menu-link">Investissement locatif</a></li>
<li id="menu-item-914" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-914"><a target="_blank" href="https://www.ubireal.fr/" class="menu-link">Gestion locative</a></li>
<li id="menu-item-915" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-915"><a target="_blank" href="https://www.revaloc.fr/" class="menu-link">Gestion des travaux</a></li>
<li id="menu-item-5941" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-5941"><a href="https://squibly.fr/" class="menu-link">Gestion comptable simplifiée</a></li>
<li id="menu-item-15183" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-15183"><a href="https://balancetonsquat.fr" class="menu-link">Action contre le squat</a></li>
<li id="menu-item-916" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-916"><a target="_blank" href="https://www.banquos.fr/" class="menu-link">Financez votre bien</a></li>
</ul></nav></section>		</aside>
						</div>
											<div class="site-footer-primary-section-3 site-footer-section site-footer-section-3">
							<aside
		class="footer-widget-area widget-area site-footer-focus-item footer-widget-area-inner" data-section="sidebar-widgets-footer-widget-2" aria-label="Footer Widget 2" role="region"		>
			<section id="block-22" class="widget widget_block">
<h2 class="wp-block-heading has-text-color" style="color:#ffffff"><strong>LIENS UTILES</strong></h2>
</section><section id="nav_menu-1" class="widget widget_nav_menu"><nav class="menu-liens-utiles-container" aria-label="Menu"><ul id="menu-liens-utiles" class="menu"><li id="menu-item-1354" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1354"><a href="https://go.cashflowpositif.com/?utm_source=siteweb&#038;utm_campaign=portail_investissement&#038;utm_medium=se_connecter" class="menu-link">Portail investisseur</a></li>
<li id="menu-item-1355" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1355"><a href="https://cashflowpositif.com/equipe-cash-flow-positif/" class="menu-link">Nous rejoindre</a></li>
<li id="menu-item-1340" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-1340"><a href="https://cashflowpositif.com/articles/" class="menu-link">Ressources</a></li>
<li id="menu-item-6198" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-6198"><a href="https://cashflowpositif.com/livre-blanc-guide-dinvestissement-locatif/" class="menu-link">Livre blanc</a></li>
<li id="menu-item-2837" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2837"><a href="https://cashflowpositif.com/contact-presse/" class="menu-link">Presse</a></li>
<li id="menu-item-1344" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1344"><a href="https://cashflowpositif.com/faq/" class="menu-link">FAQ</a></li>
</ul></nav></section>		</aside>
						</div>
											<div class="site-footer-primary-section-4 site-footer-section site-footer-section-4">
							<aside
		class="footer-widget-area widget-area site-footer-focus-item footer-widget-area-inner" data-section="sidebar-widgets-footer-widget-4" aria-label="Footer Widget 4" role="region"		>
			<section id="block-24" class="widget widget_block">
<h2 class="wp-block-heading">RESSOURCES</h2>
</section><section id="nav_menu-8" class="widget widget_nav_menu"><nav class="menu-ressources-container" aria-label="Menu"><ul id="menu-ressources" class="menu"><li id="menu-item-6619" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6619"><a href="https://cashflowpositif.com/livre-blanc-guide-dinvestissement-locatif/" class="menu-link">Livre Blanc</a></li>
<li id="menu-item-6618" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6618"><a href="https://cashflowpositif.com/cash-flow-positif-vs-masteos/" class="menu-link">Cash Flow Positif vs Masteos</a></li>
<li id="menu-item-6622" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6622"><a href="https://cashflowpositif.com/cash-flow-positif-vs-investissement-locatif/" class="menu-link">Cash Flow Positif vs Investissement Locatif</a></li>
<li id="menu-item-6616" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6616"><a href="https://cashflowpositif.com/cash-flow-positif-vs-beanstock/" class="menu-link">Cash Flow Positif vs Beanstock</a></li>
<li id="menu-item-6617" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6617"><a href="https://cashflowpositif.com/cash-flow-positif-vs-bevouac/" class="menu-link">Cash Flow Positif vs Bevouac</a></li>
<li id="menu-item-6620" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6620"><a href="https://cashflowpositif.com/landing-page-immo/" class="menu-link">Investissement immobilier</a></li>
<li id="menu-item-6621" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6621"><a href="https://cashflowpositif.com/landing-page-sci/" class="menu-link">Rentabilisation du SCI</a></li>
<li id="menu-item-8045" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-8045"><a href="https://cashflowpositif.com/campagne-immeuble-2025/" class="menu-link">Un bien acheté, un immeuble offert</a></li>
</ul></nav></section>		</aside>
						</div>
											<div class="site-footer-primary-section-5 site-footer-section site-footer-section-5">
								<div class="ast-builder-layout-element ast-flex site-footer-focus-item" data-section="section-fb-social-icons-1">
				<div class="ast-footer-social-1-wrap ast-footer-social-wrap"><div class="footer-social-inner-wrap element-social-inner-wrap social-show-label-false ast-social-color-type-custom ast-social-stack-none ast-social-element-style-filled"><a href="https://www.facebook.com/cashflowpositif/" aria-label="Facebook" target="_blank" rel="noopener noreferrer" style="--color: #557dbc; --background-color: transparent;" class="ast-builder-social-element ast-inline-flex ast-facebook footer-social-item"><span aria-hidden="true" class="ahfb-svg-iconset ast-inline-flex svg-baseline"><svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 320 512'><path d='M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z'></path></svg></span></a><a href="https://www.instagram.com/cashflowpositif/" aria-label="Instagram" target="_blank" rel="noopener noreferrer" style="--color: #8a3ab9; --background-color: transparent;" class="ast-builder-social-element ast-inline-flex ast-instagram footer-social-item"><span aria-hidden="true" class="ahfb-svg-iconset ast-inline-flex svg-baseline"><svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'><path d='M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z'></path></svg></span></a><a href="https://twitter.com/CashFlowPositif?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor" aria-label="Twitter" target="_blank" rel="noopener noreferrer" style="--color: #7acdee; --background-color: transparent;" class="ast-builder-social-element ast-inline-flex ast-twitter footer-social-item"><span aria-hidden="true" class="ahfb-svg-iconset ast-inline-flex svg-baseline"><svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'><path d='M18.244 2.25H21.552L14.325 10.51L22.827 21.75H16.17L10.956 14.933L4.99 21.75H1.68L9.41 12.915L1.254 2.25H8.08L12.793 8.481L18.244 2.25ZM17.083 19.77H18.916L7.084 4.126H5.117L17.083 19.77Z'/></svg></span></a><a href="https://www.linkedin.com/company/cash-flow-positif/" aria-label="Linkedin" target="_blank" rel="noopener noreferrer" style="--color: #1c86c6; --background-color: transparent;" class="ast-builder-social-element ast-inline-flex ast-linkedin footer-social-item"><span aria-hidden="true" class="ahfb-svg-iconset ast-inline-flex svg-baseline"><svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'><path d='M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z'></path></svg></span></a></div></div>			</div>
						</div>
										</div>
			</div>

</div>
<div class="site-below-footer-wrap ast-builder-grid-row-container site-footer-focus-item ast-builder-grid-row-2-equal ast-builder-grid-row-tablet-2-equal ast-builder-grid-row-mobile-full ast-footer-row-stack ast-footer-row-tablet-stack ast-footer-row-mobile-stack" data-section="section-below-footer-builder">
	<div class="ast-builder-grid-row-container-inner">
					<div class="ast-builder-footer-grid-columns site-below-footer-inner-wrap ast-builder-grid-row">
											<div class="site-footer-below-section-1 site-footer-section site-footer-section-1">
								<div class="ast-builder-layout-element ast-flex site-footer-focus-item ast-footer-copyright" data-section="section-footer-builder">
				<div class="ast-footer-copyright"><p>Copyright &copy; 2025 Cash Flow Positif - Cash Flow Positif SAS</p>
</div>			</div>
						</div>
											<div class="site-footer-below-section-2 site-footer-section site-footer-section-2">
							<div class="footer-widget-area widget-area site-footer-focus-item ast-footer-html-1" data-section="section-fb-html-1">
			<div class="ast-header-html inner-link-style-"><div class="ast-builder-html-element"><p style="text-align: center"><span style="color: #bdbdbd"><span style="font-size: 9pt">34, AVENUE DES CHAMPS-ÉLYSÉES 75008 PARIS | +33  1  <span data-teams="true">76 34 03 77</span><br />
</span><span style="font-size: 9pt">Carte Pro. 8401 2020 000 045 188</span></span></p>
</div></div>		</div>
						</div>
										</div>
			</div>

</div>
	</footer><!-- #colophon -->
	</div><!-- #page -->
<script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"\/*"},{"not":{"href_matches":["\/wp-*.php","\/wp-admin\/*","\/wp-content\/uploads\/*","\/wp-content\/*","\/wp-content\/plugins\/*","\/wp-content\/themes\/astra-child\/*","\/wp-content\/themes\/astra\/*","\/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
    <script type="text/javascript">
		_linkedin_partner_id = "3962921";
		window._linkedin_data_partner_ids = window._linkedin_data_partner_ids || [];
		window._linkedin_data_partner_ids.push(_linkedin_partner_id);
	</script>
	<script src="https://cc.cdn.civiccomputing.com/9/cookieControl-9.x.min.js"></script>
	<script type="text/javascript">
		// Fonction pour vérifier la présence des paramètres UTM
        function hasUTMParameters() {
            const urlParams = new URLSearchParams(window.location.search);
            const utmKeys = ['utm_source', 'utm_medium', 'utm_campaign'];
            return utmKeys.some(key => urlParams.has(key));
        }

        // Fonction pour ajouter les paramètres UTM par défaut et rediriger si nécessaire
        function addDefaultUTMParameters() {
			if (!hasUTMParameters()) {
				const urlParams = new URLSearchParams(window.location.search);
				const affiliate = urlParams.get('affiliate'); // Vérifie si un paramètre 'affiliate' est présent

				let defaultUTMs = {
					utm_source: 'web',
					utm_medium: 'homepage',
					utm_campaign: affiliate ? affiliate : 'organique'
				};
				
				if (window.location.href === 'https://cashflowpositif.com/campagne-immeuble-2025/') {
					defaultUTMs = {
						utm_source: 'print',
						utm_medium: 'campagne',
						utm_campaign: affiliate ? affiliate : '1-bien-achete-1-immeuble-offert'
					};
				}

				const currentUrl = new URL(window.location.href);
				Object.keys(defaultUTMs).forEach(key => {
					currentUrl.searchParams.set(key, defaultUTMs[key]);
				});

				// Rediriger vers l'URL mise à jour avec les UTMs
				window.location.href = currentUrl.toString();
				return true; // Indique qu'une redirection a été déclenchée
			}
			return false; // Aucune redirection nécessaire
		}

		
		function getUrlParameter(sParam) {
			var sPageURL = window.location.search.substring(1),
				sURLVariables = sPageURL.split('&'),
				sParameterName,
				i;

			for (i = 0; i < sURLVariables.length; i++) {
				sParameterName = sURLVariables[i].split('=');

				if (sParameterName[0] === sParam) {
					return typeof sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
				}
			}
			return false;
		}
		
		function getCookie(name){
			if(document.cookie.length == 0)
				return null;

			var regSepCookie = new RegExp('(; )', 'g');
			var cookies = document.cookie.split(regSepCookie);

			for(var i = 0; i < cookies.length; i++){
				var regInfo = new RegExp('=', 'g');
				var infos = cookies[i].split(regInfo);
				if(infos[0] == name){
					return unescape(infos[1]);
				}
			}
			return null;
		}
		
		function analyseUTMTagsAndUpdateCookies(){
			utm_source_url = null;
			if(getUrlParameter('utm_source')) {
				utm_source_url = getUrlParameter('utm_source');
			}
			utm_campaign_url = null;
			if(getUrlParameter('utm_campaign')) {
				utm_campaign_url = getUrlParameter('utm_campaign');
			}
			
			if(getUrlParameter('affiliate')) {
				document.cookie = "cfp_utm_campaign="+getUrlParameter('affiliate')+"; Secure";
			}

			utm_medium_url = null;
			if(getUrlParameter('utm_medium')) {
				utm_medium_url = getUrlParameter('utm_medium');
			}

			utm_source_cookie = getCookie('cfp_utm_source');
			utm_campaign_cookie = getCookie('cfp_utm_campaign');
			utm_medium_cookie = getCookie('cfp_utm_medium');

			if(utm_source_url !== null && utm_source_cookie === null){
				console.log('cfp_utm_source is set');
				document.cookie = "cfp_utm_source="+utm_source_url+"; Secure";
			}

			if(utm_campaign_url !== null && utm_campaign_cookie === null){
				console.log('cfp_utm_campaign is set');
				document.cookie = "cfp_utm_campaign="+utm_campaign_url+"; Secure";
			}

			if(utm_medium_url !== null && utm_medium_cookie === null){
				console.log('cfp_utm_medium is set');
				document.cookie = "cfp_utm_medium="+utm_medium_url+"; Secure";
			}
		}
		
		// Initialisation des cookies et de la bannière
        function initializeCookieBanner() {
			var config = {
				apiKey: 'c4fad702b016710c298a2d97052dbc73b8ba961a',
				product: 'PRO',
				initialState: 'notify',
				notifyOnce: true,
				text: {
					title: 'Bienvenue chez Cash Flow Positif',
					intro: 'Avec votre accord, nous utilisons des cookies ou technologies similaires pour stocker et accéder à des informations personnelles comme votre visite sur ce site. Vous pouvez retirer votre consentement ou vous opposer aux traitements basés sur l\'intérêt légitime à tout moment.',
					necessaryTitle: 'Cookies nécessaires',
					necessaryDescription: 'Certains cookies sont necessaires au bon fonctionnement du site comme par exemple pour la navigation ou bien l\'accès à des zone restreintes. Le site ne peut pas fonctionner sans ces cookies et seule une désactivation de ceux-ci via les paramètres de votre navigateur est possible.',
					accept: 'Accepter',
					reject: 'Refuser',
					settings: 'Paramètres',
					acceptSettings: 'Accepter',
					rejectSettings: "Refuser",
					readMore: "En savoir plus",
					acceptRecommended: 'Accepter les recommandations',
					notifyTitle: 'Paramètres des cookies',
					notifyDescription: 'Nous utilisons des cookies pour vous offrir la meilleure expérience possible.'
				},
				statement: {
					description: 'Pour de plus amples informations,',
					name: 'Politique de confidentialité',
					url: 'https://app.cashflowpositif.com/privacy-policies',
					updated: '09/09/2021'
				},
				settingsStyle: 'button',
				layout: 'slideout',
				position: 'LEFT',
				theme: 'DARK',
				closeOnGlobalChange: true,
				notifyDismissButton: true,
				toggleType: 'slider',
				closeStyle: 'icon',
				optionalCookies: [
					{
						name: 'analytics',
						label: 'Ces cookies nous aident à adapter notre service à vos besoins en collectant et analysant l\'utilisation faite du site et votre parcours client.',
						description: 'Les cookies, identifiants de votre terminal ou autres informations peuvent être stockés ou consultés sur votre terminal pour les finalités qui vous sont présentées.',
						cookies: ['_fbp', '_ga', '_gid', '_gat', '__utma', '__utmt', '__utmb', '__utmc', '__utmz', 'affiliate', 'affiliate_id', '__utmv','_gat', 'fr', 'xs', 'dpr', 'wd', 'c_user', 'locale', 'presence', 'sb', 'usida', '__cf_bm', 'pipe-last-active', 'intercom-session-hqausqan', 'pd_referrer', 'spin', 'OptanonConsent', 'last_user_id', 'has_account', 'fs_uid', 'optimizelyEndUserId', '_rdt_uuid', 'device_id', 'pipe-session-token', '_gcl_au', 'pipe-session', 'pd_account', 'wordpress_sec_78fd937b08db34c37efb1b75a5ad91b4', 'ajs_anonymous_id', 'datr', 'ajs_user_id', 'OptanonAlertBoxClosed', 'wordpress_logged_in_78fd937b08db34c37efb1b75a5ad91b4', 'country', 'pd_referrer_session', 'wordpress_test_cookie', 'pd_language_selection'],
						recommendedState: true,
						onAccept: function(){
							// Add Google Analytics
							(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
								(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
								m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
							})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

							// Add Linkedin Ads
							(function(l) {
								if (!l){window.lintrk = function(a,b){window.lintrk.q.push([a,b])};
									window.lintrk.q=[]}
								var s = document.getElementsByTagName("script")[0];
								var b = document.createElement("script");
								b.type = "text/javascript";b.async = true;
								b.src = "https://snap.licdn.com/li.lms-analytics/insight.min.js";
								s.parentNode.insertBefore(b, s);})(window.lintrk);

							ga('create', 'UA-154912861-1', 'auto');
							ga('set', 'hostname', 'cashflowpositif.com');
							ga('linker:autoLink', ['app.cashflowpositif.com']);
							ga('send', 'pageview');

							console.log('accepted_analytics');
						},
						onRevoke: function(){
							fbq('consent', 'revoke');
							window['ga-disable-UA-154912861-1'] = true;
							console.log('refused_analytics');
						}
					},
					{
						name: 'affiliate',
						label: 'Ces cookies nous permettent de mieux connaitre la source de votre visite ainsi que les personnes nous recommandant.',
						description: 'Les cookies, identifiants de votre terminal ou autres informations peuvent être stockés ou consultés sur votre terminal pour les finalités qui vous sont présentées.',
						cookies: ['cfp_utm_source', 'cfp_utm_campaign', 'cfp_utm_medium', 'affiliate', 'affiliate_id', 'city_insights_first_name', 'city_insights_last_name', 'city_insights_email', 'city_insights_contact_option', 'city_insights_news_letter'],
						recommendedState: true,
						onAccept: function(){
							//AFFILIATE PROGRAM
							if(getUrlParameter('affiliate') != "" && getCookie('affiliate') == null){
								$.ajax({
									url: $AFFILIATE_TRACKING_URL,
									method: 'GET',
									data: {
										'affiliate': getUrlParameter('affiliate')
									}
								});
							}

							// UTM tags
							analyseUTMTagsAndUpdateCookies();
							console.log('accepted_affiliate');
						},
						onRevoke: function(){
							console.log('refused_affiliate');
						}
					}
				],
				branding: {
					backgroundColor: '#000',
					toggleText: '#000',
					toggleColor: '#f0f0f0',
					toggleBackground: '#000',
					buttonIcon: null,
					buttonIconWidth: 80,
					buttonIconHeight: 80,
					removeIcon: false,
					removeAbout: true
				},
				accessibility: {
					overlay: false,      // Désactive l'overlay qui obscurcit le site
					highlightFocus: true // Accentue les éléments en focus pour l'accessibilité
				},
				locale: "fr_FR"
			};

			CookieControl.load(config);
		}
		
		// Gestion de la redirection et initialisation
		document.addEventListener("DOMContentLoaded", function() {
            const redirected = addDefaultUTMParameters();
            if (!redirected) {
                initializeCookieBanner();
            }
        });
		
		jQuery(document).ready(function($) {
			if (window.location.href.startsWith('https://cashflowpositif.com/livre-blanc-guide-dinvestissement-locatif/')) {

				// Styles pour les messages d'erreur
				$('<style>')
					.text(`
						.error-message {
							color: #dc3545;
							font-size: 14px;
							margin-top: 5px;
							display: block;
						}
						.input-error {
							border-color: #dc3545 !important;
						}
					`)
					.appendTo('head');

				// Fonction pour récupérer un cookie par son nom
				function getCookie(name) {
					const value = `; ${document.cookie}`;
					const parts = value.split(`; ${name}=`);
					if (parts.length === 2) return parts.pop().split(';').shift();
					return null;
				}

				$('#submitLivreBlanc').on('click', function(e) {
					e.preventDefault();

					// Supprimer les anciens messages d'erreur
					$('.error-message').remove();
					$('input').removeClass('input-error');

					// Validation des champs requis
					const fields = [
						{ input: 'input[placeholder="Nom"]', name: 'Nom' },
						{ input: 'input[placeholder="Prénom"]', name: 'Prénom' },
						{ input: 'input[placeholder="Adresse mail"]', name: 'Adresse mail' },
						{ input: 'input[placeholder="Numéro de téléphone"]', name: 'Numéro de téléphone' }
					];

					let hasError = false;

					// Validation des champs texte
					fields.forEach(field => {
						const inputElement = $(field.input);
						const value = inputElement.val();

						if (!value || value.trim() === '') {
							hasError = true;
							inputElement.addClass('input-error');
							inputElement.after(`<span class="error-message">Le champ ${field.name} est requis</span>`);
						}
					});

					// Validation de la checkbox
					const checkbox = $('#form-field-field_checkbox');
					if (!checkbox.is(':checked')) {
						hasError = true;
						checkbox.addClass('input-error');
						checkbox.parent().after('<span class="error-message">Vous devez accepter les conditions</span>');
					}

					// Si pas d'erreur, procéder à l'envoi du formulaire
					if (!hasError) {
						// Récupérer les UTMs depuis les cookies
						const utmParams = {};
						const paramList = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'gclid', 'fbclid', 'affiliate', 'source', 'campaign'];

						paramList.forEach(param => {
							const value = getCookie(param);
							if (value) {
								utmParams[param] = value;
							}
						});

						// Récupérer les données du formulaire et combiner avec les UTMs
						var formData = {
							firstName: jQuery('input[placeholder="Nom"]').val(),
							lastName: jQuery('input[placeholder="Prénom"]').val(),
							email: jQuery('input[placeholder="Adresse mail"]').val(),
							phoneNumber: jQuery('input[placeholder="Numéro de téléphone"]').val(),
							...utmParams
						};

						// Envoie des données au serveur via une requête AJAX
						$.ajax({
							url: 'https://app.cashflowpositif.com/api/sales-lead/livreblanc',
							type: 'POST',
							data: JSON.stringify(formData),
							contentType: 'application/json',
							success: function(response) {
								// Push event to the data layer
								window.dataLayer = window.dataLayer || [];
								window.dataLayer.push({
									event: 'formSubmitSuccess',
									formName: 'LivreBlancGuideInvestissement',
									formData: formData
								});

								// Redirect to the download page
								window.location.href = 'https://cashflowpositif.com/wp-content/uploads/2024/10/Livre-Blanc-CFP.pdf';
							},
							error: function(error) {
								alert('Une erreur est survenue. Veuillez réessayer.');
							}
						});
					}
				});
			}
		});
	</script>
    			<script>
				const lazyloadRunObserver = () => {
					const lazyloadBackgrounds = document.querySelectorAll( `.e-con.e-parent:not(.e-lazyloaded)` );
					const lazyloadBackgroundObserver = new IntersectionObserver( ( entries ) => {
						entries.forEach( ( entry ) => {
							if ( entry.isIntersecting ) {
								let lazyloadBackground = entry.target;
								if( lazyloadBackground ) {
									lazyloadBackground.classList.add( 'e-lazyloaded' );
								}
								lazyloadBackgroundObserver.unobserve( entry.target );
							}
						});
					}, { rootMargin: '200px 0px 200px 0px' } );
					lazyloadBackgrounds.forEach( ( lazyloadBackground ) => {
						lazyloadBackgroundObserver.observe( lazyloadBackground );
					} );
				};
				const events = [
					'DOMContentLoaded',
					'elementor/lazyload/observe',
				];
				events.forEach( ( event ) => {
					document.addEventListener( event, lazyloadRunObserver );
				} );
			</script>
			<link rel='stylesheet' id='jeg-dynamic-style-css' href='https://cashflowpositif.com/wp-content/plugins/jeg-elementor-kit/lib/jeg-framework/assets/css/jeg-dynamic-styles.css?ver=1.3.0' media='all' />
<script defer='defer' src="https://cashflowpositif.com/wp-includes/js/imagesloaded.min.js?ver=5.0.0" id="imagesloaded-js"></script>
<script defer='defer' src="https://cashflowpositif.com/wp-includes/js/masonry.min.js?ver=4.2.2" id="masonry-js"></script>
<script defer='defer' src="https://cashflowpositif.com/wp-content/plugins/betterdocs/assets/blocks/categorygrid/frontend.js?ver=a4a7e7ed1fd9a2aaf85a" id="betterdocs-categorygrid-js"></script>
<script id="astra-theme-js-js-extra">
var astra = {"break_point":"921","isRtl":"","is_scroll_to_id":"","is_scroll_to_top":"","is_header_footer_builder_active":"1","responsive_cart_click":"flyout","is_dark_palette":""};
</script>
<script defer='defer' src="https://cashflowpositif.com/wp-content/themes/astra/assets/js/minified/frontend.min.js?ver=4.11.16" id="astra-theme-js-js"></script>
<script id="eae-main-js-extra">
var eae = {"ajaxurl":"https:\/\/cashflowpositif.com\/wp-admin\/admin-ajax.php","current_url":"aHR0cHM6Ly9jYXNoZmxvd3Bvc2l0aWYuY29tL3NpZ25hbHMvaXdsLmpzLw==","nonce":"7741a4aa48","plugin_url":"https:\/\/cashflowpositif.com\/wp-content\/plugins\/addon-elements-for-elementor-page-builder\/"};
var eae_editor = {"plugin_url":"https:\/\/cashflowpositif.com\/wp-content\/plugins\/addon-elements-for-elementor-page-builder\/"};
</script>
<script defer='defer' src="https://cashflowpositif.com/wp-content/plugins/addon-elements-for-elementor-page-builder/assets/js/eae.min.js?ver=1.14.3" id="eae-main-js"></script>
<script defer='defer' src="https://cashflowpositif.com/wp-content/plugins/addon-elements-for-elementor-page-builder/build/index.min.js?ver=1.14.3" id="eae-index-js"></script>
<script defer='defer' src="https://cashflowpositif.com/wp-content/plugins/elementor/assets/lib/font-awesome/js/v4-shims.min.js?ver=1.0" id="font-awesome-4-shim-js"></script>
<script defer='defer' src="https://cashflowpositif.com/wp-content/plugins/addon-elements-for-elementor-page-builder/assets/js/animated-main.min.js?ver=1.0" id="animated-main-js"></script>
<script defer='defer' src="https://cashflowpositif.com/wp-content/plugins/addon-elements-for-elementor-page-builder/assets/js/particles.min.js?ver=2.0.0" id="eae-particles-js"></script>
<script defer='defer' src="https://cashflowpositif.com/wp-content/plugins/addon-elements-for-elementor-page-builder/assets/lib/magnific.min.js?ver=1.1.0" id="wts-magnific-js"></script>
<script defer='defer' src="https://cashflowpositif.com/wp-content/plugins/addon-elements-for-elementor-page-builder/assets/lib/vegas/vegas.min.js?ver=2.4.0" id="vegas-js"></script>
<script defer='defer' src="https://cashflowpositif.com/wp-content/plugins/metform/public/assets/lib/cute-alert/cute-alert.js?ver=4.0.8" id="cute-alert-js"></script>
<script defer='defer' src="https://cashflowpositif.com/wp-content/plugins/elementskit-lite/libs/framework/assets/js/frontend-script.js?ver=3.7.6" id="elementskit-framework-js-frontend-js"></script>
<script id="elementskit-framework-js-frontend-js-after">
		var elementskit = {
			resturl: 'https://cashflowpositif.com/wp-json/elementskit/v1/',
		}

		
</script>
<script defer='defer' src="https://cashflowpositif.com/wp-content/plugins/elementskit-lite/widgets/init/assets/js/widget-scripts.js?ver=3.7.6" id="ekit-widget-scripts-js"></script>
<script defer='defer' src="https://cashflowpositif.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.33.2" id="elementor-webpack-runtime-js"></script>
<script defer='defer' src="https://cashflowpositif.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.33.2" id="elementor-frontend-modules-js"></script>
<script defer='defer' src="https://cashflowpositif.com/wp-includes/js/jquery/ui/core.min.js?ver=1.13.3" id="jquery-ui-core-js"></script>
<script defer='defer' src="https://cashflowpositif.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.33.2" id="elementor-frontend-js"></script>
<script id="elementor-frontend-js-after">
var jkit_ajax_url = "https://cashflowpositif.com/?jkit-ajax-request=jkit_elements", jkit_nonce = "09eca9914a";
</script>
<script defer='defer' src="https://cashflowpositif.com/wp-content/plugins/jeg-elementor-kit/assets/js/elements/sticky-element.js?ver=3.0.1" id="jkit-sticky-element-js"></script>
<script id="fca_pc_client_js-js-extra">
var fcaPcEvents = [{"triggerType":"exact_url","trigger":"https:\/\/cashflowpositif.com\/prendre-rendez-vous\/?","parameters":{},"pixel_type":"Facebook","event":"Prendre RDV Expert","delay":"0","scroll":"0","apiAction":"trackCustom","ID":"1ea3e7fc-b480-4bdd-9ba3-3bac911c9939"},{"triggerType":"exact_url","trigger":"https:\/\/cashflowpositif.com\/projects\/?","parameters":{},"pixel_type":"Facebook","event":"view r\u00e9alisation","delay":"0","scroll":"0","apiAction":"trackCustom","ID":"fae6959b-4fc9-4cd7-a111-dfdc81718dcb"},{"triggerType":"exact_url","trigger":"https:\/\/cashflowpositif.com\/wp-content\/uploads\/2024\/10\/Livre-Blanc-CFP.pdf","parameters":{},"pixel_type":"Facebook","event":"Livre blanc 2024","delay":"0","scroll":"0","apiAction":"trackCustom","ID":"c34b543e-dd3c-4643-9e38-d2125d10f87f"}];
var fcaPcPost = {"title":"","type":"","id":"0","categories":[]};
var fcaPcOptions = {"pixel_types":["Conversions API"],"capis":{"Conversions API":true},"ajax_url":"https:\/\/cashflowpositif.com\/wp-admin\/admin-ajax.php","debug":"","edd_currency":"USD","nonce":"d60ce0082e","utm_support":"","user_parameters":"","edd_enabled":"","edd_delay":"0","woo_enabled":"","woo_delay":"0","woo_order_cookie":"","video_enabled":""};
</script>
<script defer='defer' src="https://cashflowpositif.com/wp-content/plugins/facebook-conversion-pixel/pixel-cat.min.js?ver=3.2.0" id="fca_pc_client_js-js"></script>
<script defer='defer' src="https://cashflowpositif.com/wp-content/plugins/facebook-conversion-pixel/video.js?ver=6.8.3" id="fca_pc_video_js-js"></script>
			<script>
			/(trident|msie)/i.test(navigator.userAgent)&&document.getElementById&&window.addEventListener&&window.addEventListener("hashchange",function(){var t,e=location.hash.substring(1);/^[A-z0-9_-]+$/.test(e)&&(t=document.getElementById(e))&&(/^(?:a|select|input|button|textarea)$/i.test(t.tagName)||(t.tabIndex=-1),t.focus())},!1);
			</script>
				</body>
</html>
